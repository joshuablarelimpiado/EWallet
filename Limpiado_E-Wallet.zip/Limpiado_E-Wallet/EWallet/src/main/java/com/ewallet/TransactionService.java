package com.ewallet;

import java.sql.*;
import java.time.LocalDateTime;

/**
 * Owns wallet money movement: deposits, withdrawals, transfers, reward
 * points, and transaction lookups. This changes only when the rules for
 * moving money change — not when user-lookup or admin-audit code changes,
 * which is what "single responsibility" buys you here: three separate,
 * independently-modifiable classes instead of one that does everything.
 */
public class TransactionService {

    private static final int PESOS_PER_POINT = 10_000;

    /** Adapter: translates a raw JDBC row into a Transaction domain object. See RowMapper. */
    private static final RowMapper<Transaction> TRANSACTION_MAPPER = rs -> {
        Timestamp ts = rs.getTimestamp("created_at");
        LocalDateTime dateTime = ts != null ? ts.toLocalDateTime() : LocalDateTime.now();
        return new Transaction(
                rs.getInt("id"),
                rs.getString("type"),
                rs.getDouble("amount"),
                rs.getDouble("balance_after"),
                dateTime
        );
    };

    /** Observers notified after every completed deposit, withdrawal, or transfer. See TransactionObserver. */
    private final java.util.List<TransactionObserver> observers = new java.util.ArrayList<>();

    public void addObserver(TransactionObserver observer) {
        observers.add(observer);
    }

    private void notifyObservers(User actingUser, Transaction transaction) {
        for (TransactionObserver observer : observers) {
            observer.onTransaction(actingUser, transaction);
        }
    }

    public void deposit(User user, double amount) {
        double newBalance = user.getBalance() + amount;
        try (Connection conn = Database.connect()) {
            conn.setAutoCommit(false);
            try {
                updateBalance(conn, user.getId(), newBalance);
                int transactionId = insertTransaction(conn, user.getId(), "Cash In (Deposit)", amount, newBalance);
                int newPoints = awardPoints(conn, user.getId(), amount);
                conn.commit();
                user.setBalance(newBalance);
                user.setPoints(newPoints);

                // Factory builds the domain object; observers get told a deposit happened.
                Transaction transaction = TransactionFactory.createDeposit(
                        transactionId, amount, newBalance, LocalDateTime.now());
                notifyObservers(user, transaction);
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (SQLException e) {
            Database.showConnectionError(e);
        }
    }

    public boolean withdraw(User user, double amount) {
        try (Connection conn = Database.connect()) {
            conn.setAutoCommit(false);
            try {
                // Re-check balance inside the transaction to avoid a stale read.
                double currentBalance = lockAndGetBalance(conn, user.getId());
                if (amount > currentBalance) {
                    conn.rollback();
                    return false;
                }
                double newBalance = currentBalance - amount;
                updateBalance(conn, user.getId(), newBalance);
                int transactionId = insertTransaction(conn, user.getId(), "Cash Out (Withdraw)", -amount, newBalance);
                int newPoints = awardPoints(conn, user.getId(), amount);
                conn.commit();
                user.setBalance(newBalance);
                user.setPoints(newPoints);

                Transaction transaction = TransactionFactory.createWithdrawal(
                        transactionId, amount, newBalance, LocalDateTime.now());
                notifyObservers(user, transaction);
                return true;
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (SQLException e) {
            Database.showConnectionError(e);
            return false;
        }
    }

    /**
     * Transfer, wrapped in a single DB transaction. Both balance updates
     * and both transaction log entries commit together or not at all,
     * preventing the double-spend / partial-transfer race that existed
     * with separate auto-committed statements.
     */
    public boolean transfer(User sender, User recipient, double amount) {
        try (Connection conn = Database.connect()) {
            conn.setAutoCommit(false);
            try {
                double senderBalance = lockAndGetBalance(conn, sender.getId());
                if (amount > senderBalance) {
                    conn.rollback();
                    return false;
                }
                double recipientBalance = lockAndGetBalance(conn, recipient.getId());

                double senderNewBalance = senderBalance - amount;
                double recipientNewBalance = recipientBalance + amount;

                updateBalance(conn, sender.getId(), senderNewBalance);
                updateBalance(conn, recipient.getId(), recipientNewBalance);

                int sentTxId = insertTransaction(conn, sender.getId(), "Sent to " + recipient.getUsername(), -amount, senderNewBalance);
                int receivedTxId = insertTransaction(conn, recipient.getId(), "Received from " + sender.getUsername(), amount, recipientNewBalance);

                int senderNewPoints = awardPoints(conn, sender.getId(), amount);

                conn.commit();

                sender.setBalance(senderNewBalance);
                sender.setPoints(senderNewPoints);
                recipient.setBalance(recipientNewBalance);

                LocalDateTime now = LocalDateTime.now();
                Transaction sentTx = TransactionFactory.createTransferSent(
                        sentTxId, amount, senderNewBalance, recipient.getUsername(), now);
                Transaction receivedTx = TransactionFactory.createTransferReceived(
                        receivedTxId, amount, recipientNewBalance, sender.getUsername(), now);
                notifyObservers(sender, sentTx);
                notifyObservers(recipient, receivedTx);
                return true;
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (SQLException e) {
            Database.showConnectionError(e);
            return false;
        }
    }

    /** Looks up a single transaction by id, scoped to a user (so users can't view others' receipts by guessing ids). */
    public Transaction findTransaction(int userId, int transactionId) {
        String sql = "SELECT * FROM transactions WHERE id = ? AND user_id = ?";
        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, transactionId);
            ps.setInt(2, userId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapTransaction(rs);
        } catch (SQLException e) {
            Database.showConnectionError(e);
        }
        return null;
    }

    // ---------------------------------------------------------------
    // Internal helpers
    // ---------------------------------------------------------------

    /** Reads a user's current balance with a row lock, inside an existing transaction. */
    private double lockAndGetBalance(Connection conn, int userId) throws SQLException {
        String sql = "SELECT balance FROM users WHERE id = ? FOR UPDATE";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getDouble("balance");
            throw new SQLException("User not found: " + userId);
        }
    }

    /**
     * Awards reward points at 1 pt per PESOS_PER_POINT moved, and returns
     * the user's updated point total. Must be called within an existing
     * transaction/connection so it commits atomically with the balance change.
     */
    private int awardPoints(Connection conn, int userId, double amountMoved) throws SQLException {
        int earned = (int) (Math.abs(amountMoved) / PESOS_PER_POINT);
        if (earned <= 0) {
            return getPoints(conn, userId);
        }
        String sql = "UPDATE users SET points = points + ? WHERE id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, earned);
            ps.setInt(2, userId);
            ps.executeUpdate();
        }
        return getPoints(conn, userId);
    }

    private int getPoints(Connection conn, int userId) throws SQLException {
        String sql = "SELECT points FROM users WHERE id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt("points");
            return 0;
        }
    }

    private void updateBalance(Connection conn, int userId, double newBalance) throws SQLException {
        String sql = "UPDATE users SET balance = ? WHERE id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDouble(1, newBalance);
            ps.setInt(2, userId);
            ps.executeUpdate();
        }
    }

    /** Inserts a transaction row and returns its generated id (used to build the Transaction via TransactionFactory). */
    private int insertTransaction(Connection conn, int userId, String type, double amount, double balanceAfter) throws SQLException {
        String sql = "INSERT INTO transactions (user_id, type, amount, balance_after) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, userId);
            ps.setString(2, type);
            ps.setDouble(3, amount);
            ps.setDouble(4, balanceAfter);
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                return keys.next() ? keys.getInt(1) : -1;
            }
        }
    }

    /** Uses the RowMapper adapter instead of hand-rolled mapping. See RowMapper. */
    private Transaction mapTransaction(ResultSet rs) throws SQLException {
        return TRANSACTION_MAPPER.map(rs);
    }
}
