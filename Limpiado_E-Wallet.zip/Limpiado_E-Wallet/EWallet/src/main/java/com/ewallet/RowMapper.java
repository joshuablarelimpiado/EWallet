package com.ewallet;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Adapter Pattern (Structural).
 *
 * JDBC hands back rows as a raw java.sql.ResultSet — a low-level, cursor-style
 * API that nothing in this codebase's domain layer (User, Transaction) wants
 * to depend on directly. Both UserRepository and TransactionService already
 * had private mapUser()/mapTransaction() methods doing this translation
 * by hand; RowMapper<T> pulls that "adapt a ResultSet row into a domain
 * object" role out into a proper interface so any repository can plug in
 * a mapper without duplicating the pattern, and so mapping logic can be
 * reused, tested, or swapped independently of the SQL that produces the rows.
 *
 * This is the classic Adapter shape: ResultSet is the incompatible existing
 * interface, T (User, Transaction, ...) is what the rest of the app expects,
 * and a RowMapper implementation is the adapter that bridges the two.
 */
public interface RowMapper<T> {
    T map(ResultSet rs) throws SQLException;
}
