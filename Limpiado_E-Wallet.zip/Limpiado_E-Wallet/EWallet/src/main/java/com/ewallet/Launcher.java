package com.ewallet;

/**
 * Plain entry point (does NOT extend javafx.application.Application).
 *
 * Why this exists:
 * When a class extends Application and you run it directly (e.g. via
 * IntelliJ's green ▶ button), the JVM checks for JavaFX modules on the
 * module path BEFORE your code even runs, and throws:
 *   "Error: JavaFX runtime components are missing, and are required to run this application"
 *
 * By launching JavaFX from a separate class that has no direct
 * superclass relationship to Application, that early module-path check
 * is skipped, and JavaFX initializes normally from the classpath instead.
 *
 * Just click ▶ on THIS file's main() instead of Main.java's.
 */
public class Launcher {
    public static void main(String[] args) {
        Main.main(args);
    }
}
