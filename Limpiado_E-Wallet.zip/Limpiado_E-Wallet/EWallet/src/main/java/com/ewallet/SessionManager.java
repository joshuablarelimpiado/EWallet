package com.ewallet;

import java.io.*;

/**
 * Manages the on-disk session file using Java Serialization.
 *
 * Lifecycle:
 *  - save(user):  called once, right after a successful login. Wraps the
 *                 logged-in user in a UserSession and writes it to
 *                 session.dat with ObjectOutputStream.
 *  - load():      called on app startup (and anywhere else that needs to
 *                 check "is someone logged in?"). Reads session.dat back
 *                 into a UserSession with ObjectInputStream. Returns null
 *                 if there is no session, or if the file is missing/corrupt.
 *  - clear():     called on logout. Deletes session.dat so no session
 *                 persists, then the caller sends the user back to the
 *                 login screen.
 */
public class SessionManager {

    private static final String SESSION_FILE = "session.dat";

    /** Serializes the given user's session info to session.dat. */
    public static void save(User user) {
        UserSession session = new UserSession(user);
        try (ObjectOutputStream out =
                     new ObjectOutputStream(new FileOutputStream(SESSION_FILE))) {
            out.writeObject(session);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /** Deserializes session.dat, or returns null if no valid session exists. */
    public static UserSession load() {
        File file = new File(SESSION_FILE);
        if (!file.exists()) return null;

        try (ObjectInputStream in =
                     new ObjectInputStream(new FileInputStream(file))) {
            Object obj = in.readObject();
            return (obj instanceof UserSession) ? (UserSession) obj : null;
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            // Corrupt or unreadable session file — treat as "no session".
            file.delete();
            return null;
        }
    }

    /** Deletes session.dat, ending the session. */
    public static void clear() {
        File file = new File(SESSION_FILE);
        if (file.exists()) file.delete();
    }
}
