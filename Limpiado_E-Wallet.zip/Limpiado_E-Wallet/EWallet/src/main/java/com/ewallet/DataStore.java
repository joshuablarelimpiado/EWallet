package com.ewallet;

/**
 * Static facade kept for backwards compatibility with existing call sites
 * (DashboardView, LoginView, RegisterView, etc. all call DataStore.xxx()
 * directly). The actual work is delegated to three focused classes, each
 * with a single responsibility:
 *
 *  - UserRepository:    user lookups, registration, account settings
 *  - TransactionService: deposits, withdrawals, transfers, reward points
 *  - AdminAuditService:  admin activation actions + audit log
 *
 * Splitting DataStore this way is what the Single Responsibility Principle
 * refactor was about: previously one 586-line class did all of the above
 * plus everything else — now each concern lives in its own class and can
 * change independently.
 */
public class DataStore {

    private static final UserRepository userRepository = new UserRepository();
    private static final TransactionService transactionService = new TransactionService();
    private static final AdminAuditService adminAuditService = new AdminAuditService(userRepository);

    static {
        // Observer Pattern: TransactionService notifies this logger after
        // every deposit/withdraw/transfer. See TransactionObserver.
        transactionService.addObserver(new ConsoleTransactionLogger());
    }

    public enum RegisterResult { SUCCESS, USERNAME_TAKEN, MOBILE_TAKEN, RESERVED_MOBILE, ERROR }

    // ---------------------------------------------------------------
    // User lookups / registration / account settings -> UserRepository
    // ---------------------------------------------------------------

    public static void seedDefaultAdmin() {
        userRepository.seedDefaultAdmin();
    }

    public static User findUserByMobile(String mobileNumber) {
        return userRepository.findUserByMobile(mobileNumber);
    }

    public static User findUserByMobileIncludingInactive(String mobileNumber) {
        return userRepository.findUserByMobileIncludingInactive(mobileNumber);
    }

    public static User findUserByUsername(String username) {
        return userRepository.findUserByUsername(username);
    }

    public static User findUserById(int userId) {
        return userRepository.findUserById(userId);
    }

    public static java.util.List<User> findAllUsers() {
        return userRepository.findAllUsers();
    }

    public static RegisterResult registerUser(String username, String mobileNumber, String password,
                                               String pin, String recoveryCode) {
        return userRepository.registerUser(username, mobileNumber, password, pin, recoveryCode);
    }

    public static boolean isReservedMobile(String mobileNumber) {
        return userRepository.isReservedMobile(mobileNumber);
    }

    public static boolean updateUserInfo(int userId, String newUsername, String newPassword, String newPin) {
        return userRepository.updateUserInfo(userId, newUsername, newPassword, newPin);
    }

    public static boolean resetPassword(int userId, String newPassword) {
        return userRepository.resetPassword(userId, newPassword);
    }

    public static boolean deactivateUser(int userId) {
        return userRepository.deactivateUser(userId);
    }

    public static boolean reactivateUser(int userId) {
        return userRepository.reactivateUser(userId);
    }

    // ---------------------------------------------------------------
    // Wallet operations -> TransactionService
    // ---------------------------------------------------------------

    public static void deposit(User user, double amount) {
        transactionService.deposit(user, amount);
    }

    public static boolean withdraw(User user, double amount) {
        return transactionService.withdraw(user, amount);
    }

    public static boolean transfer(User sender, User recipient, double amount) {
        return transactionService.transfer(sender, recipient, amount);
    }

    public static Transaction findTransaction(int userId, int transactionId) {
        return transactionService.findTransaction(userId, transactionId);
    }

    // ---------------------------------------------------------------
    // Admin actions / audit log -> AdminAuditService
    // ---------------------------------------------------------------

    public static boolean adminSetActive(int adminId, int targetUserId, boolean active) {
        return adminAuditService.adminSetActive(adminId, targetUserId, active);
    }

    public static java.util.List<String> getAdminAuditLog(int limit) {
        return adminAuditService.getAdminAuditLog(limit);
    }
}
