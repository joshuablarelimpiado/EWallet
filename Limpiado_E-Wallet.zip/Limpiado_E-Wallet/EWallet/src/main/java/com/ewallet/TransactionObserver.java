package com.ewallet;

/**
 * Observer Pattern (Behavioral).
 *
 * TransactionService is the subject: after a deposit, withdrawal, or
 * transfer commits successfully, it notifies every registered
 * TransactionObserver instead of having each caller manually decide what
 * else needs to happen when money moves. New reactions to a transaction
 * (audit logging, notifications, analytics, fraud checks, etc.) can be
 * added later by writing a new observer and registering it — without
 * touching TransactionService's deposit/withdraw/transfer logic at all.
 */
public interface TransactionObserver {
    void onTransaction(User user, Transaction transaction);
}
