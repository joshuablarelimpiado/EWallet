package com.ewallet;

import java.sql.*;

/**
 * Owns admin-triggered account activation/deactivation and the audit trail
 * of admin actions. Kept separate from UserRepository so that "how do I
 * change a user's active flag" (UserRepository) and "how do I log/report
 * that an admin did something" (this class) can evolve independently —
 * e.g. changing the audit log's storage or format never touches user
 * lookup/registration code.
 */
public class AdminAuditService {

    private final UserRepository userRepository;

    public AdminAuditService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public boolean adminSetActive(int adminId, int targetUserId, boolean active) {
        boolean success = active
                ? userRepository.reactivateUser(targetUserId)
                : userRepository.deactivateUser(targetUserId);
        if (success) {
            logAdminAction(adminId, active ? "REACTIVATE_USER" : "DEACTIVATE_USER", targetUserId, null);
        }
        return success;
    }

    private void logAdminAction(int adminId, String action, Integer targetUserId, String details) {
        String sql = "INSERT INTO admin_audit_log (admin_id, action, target_user_id, details) VALUES (?, ?, ?, ?)";
        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, adminId);
            ps.setString(2, action);
            if (targetUserId != null) ps.setInt(3, targetUserId); else ps.setNull(3, Types.INTEGER);
            ps.setString(4, details);
            ps.executeUpdate();
        } catch (SQLException e) {
            Database.showConnectionError(e);
        }
    }

    public java.util.List<String> getAdminAuditLog(int limit) {
        java.util.List<String> entries = new java.util.ArrayList<>();
        String sql = "SELECT a.action, a.details, a.created_at, admin.username AS admin_name, " +
                "target.username AS target_name " +
                "FROM admin_audit_log a " +
                "JOIN users admin ON a.admin_id = admin.id " +
                "LEFT JOIN users target ON a.target_user_id = target.id " +
                "ORDER BY a.created_at DESC LIMIT ?";
        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, limit);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Timestamp ts = rs.getTimestamp("created_at");
                String target = rs.getString("target_name");
                entries.add(String.format("[%s] %s %s %s",
                        ts.toLocalDateTime().format(java.time.format.DateTimeFormatter.ofPattern("MMM dd HH:mm")),
                        rs.getString("admin_name"),
                        rs.getString("action"),
                        target != null ? "-> " + target : ""));
            }
        } catch (SQLException e) {
            Database.showConnectionError(e);
        }
        return entries;
    }
}
