package com.ewallet;

/**
 * Abstraction over "how do I find a user". This is the piece that makes
 * Dependency Inversion possible in the login flow: LoginView and
 * PinUnlockView depend on this interface, not on the concrete
 * UserRepository/DataStore class.
 *
 * Today UserRepository is the only implementation (backed by MySQL), but
 * because callers only know about UserLookup, you could swap in a different
 * implementation (an in-memory fake for unit tests, a different database,
 * a caching layer) without touching LoginView or PinUnlockView at all.
 */
public interface UserLookup {
    User findUserByMobile(String mobileNumber);
    User findUserByUsername(String username);
    User findUserById(int userId);
}
