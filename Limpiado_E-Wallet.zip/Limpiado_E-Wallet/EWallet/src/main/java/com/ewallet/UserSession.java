package com.ewallet;

import java.io.Serializable;

/**
 * A lightweight, serializable snapshot of the logged-in user.
 *
 * We deliberately do NOT serialize the full {@link User} object: that class
 * carries the password hash, PIN hash, and recovery code hash, which have no
 * reason to sit in a loose file on disk. UserSession only carries what the
 * app needs to identify "who is logged in" — the rest of the user's data is
 * re-fetched from the database (via DataStore) whenever it's needed.
 */
public class UserSession implements Serializable {

    // Ties this class to a specific "version" of its shape. If you add/remove
    // fields later, ObjectInputStream uses this to detect an incompatible
    // old session.dat instead of failing in a confusing way.
    private static final long serialVersionUID = 1L;

    private final int id;
    private final String username;
    private final String mobileNumber;
    private final boolean admin;

    public UserSession(User user) {
        this.id = user.getId();
        this.username = user.getUsername();
        this.mobileNumber = user.getMobileNumber();
        this.admin = user.isAdmin();
    }

    public int getId() { return id; }
    public String getUsername() { return username; }
    public String getMobileNumber() { return mobileNumber; }
    public boolean isAdmin() { return admin; }
}
