package com.ewallet;

import java.time.LocalDateTime;

/**
 * Factory Pattern (Creational).
 *
 * TransactionService used to build "Cash In (Deposit)" / "Cash Out (Withdraw)"
 * / "Sent to X" / "Received from X" transactions by hand-formatting strings
 * and flipping the sign of amount at each call site. That logic — "what type
 * label and what signed amount does each kind of money movement produce" —
 * is exactly what a factory should own: one place that knows how to build a
 * Transaction correctly for each case, so callers just ask for the kind of
 * transaction they need instead of repeating the formatting/sign rules.
 *
 * The DB-generated id and balanceAfter aren't known until after the INSERT,
 * so those are supplied by the caller at creation time rather than guessed
 * here; the factory's job is the *type* and *signed amount*, not persistence.
 */
public class TransactionFactory {

    public static Transaction createDeposit(int id, double amount, double balanceAfter, LocalDateTime timestamp) {
        return new Transaction(id, "Cash In (Deposit)", amount, balanceAfter, timestamp);
    }

    public static Transaction createWithdrawal(int id, double amount, double balanceAfter, LocalDateTime timestamp) {
        return new Transaction(id, "Cash Out (Withdraw)", -amount, balanceAfter, timestamp);
    }

    public static Transaction createTransferSent(int id, double amount, double balanceAfter,
                                                  String recipientUsername, LocalDateTime timestamp) {
        return new Transaction(id, "Sent to " + recipientUsername, -amount, balanceAfter, timestamp);
    }

    public static Transaction createTransferReceived(int id, double amount, double balanceAfter,
                                                       String senderUsername, LocalDateTime timestamp) {
        return new Transaction(id, "Received from " + senderUsername, amount, balanceAfter, timestamp);
    }
}
