package com.ewallet;

import javafx.application.Application;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) {
        ThemeManager.load();

        DataStore.seedDefaultAdmin();

        primaryStage.setTitle("E-Wallet");
        primaryStage.setMinWidth(420);
        primaryStage.setMinHeight(480);
        SceneManager.init(primaryStage);

        UserSession activeSession = SessionManager.load();
        if (activeSession != null) {
            SceneManager.showPinUnlock(activeSession.getMobileNumber());
        } else {
            SceneManager.showLogin();
        }

        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
