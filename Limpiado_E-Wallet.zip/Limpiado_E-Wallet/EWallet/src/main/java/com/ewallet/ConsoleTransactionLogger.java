package com.ewallet;

/**
 * Concrete Observer (see TransactionObserver). Prints a one-line log entry
 * to the console whenever any user's transaction completes. Registered with
 * TransactionService in DataStore's static initializer, so it starts
 * listening as soon as the app's data layer is set up — TransactionService
 * itself has no idea this logger exists.
 */
public class ConsoleTransactionLogger implements TransactionObserver {

    @Override
    public void onTransaction(User user, Transaction transaction) {
        System.out.println("[TX LOG] " + user.getUsername() + " -> " + transaction.getDisplay());
    }
}
