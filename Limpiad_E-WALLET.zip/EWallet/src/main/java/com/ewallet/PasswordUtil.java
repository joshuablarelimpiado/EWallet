package com.ewallet;

import org.mindrot.jbcrypt.BCrypt;

public class PasswordUtil {

    
    public static String hash(String plainText) {
        return BCrypt.hashpw(plainText, BCrypt.gensalt());
    }

    
    public static boolean matches(String plainText, String hashed) {
        if (plainText == null || hashed == null) return false;
        try {
            return BCrypt.checkpw(plainText, hashed);
        } catch (IllegalArgumentException e) {

            return false;
        }
    }

    
    public static String validateStrength(String password) {
        if (password == null || password.length() < 8) {
            return "Password must be at least 8 characters long.";
        }
        if (!password.matches(".*[A-Za-z].*")) {
            return "Password must contain at least one letter.";
        }
        if (!password.matches(".*\\d.*")) {
            return "Password must contain at least one number.";
        }
        if (!password.matches(".*[!@#$%^&*()\\-_=+\\[\\]{};:'\",.<>/?].*")) {
            return "Password must contain at least one special character (e.g. !@#$%).";
        }
        return null;
    }
}
