package com.ewallet;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class User {
    private int id;
    private String username;
    private String mobileNumber;
    private String password;
    private String pin;
    private String recoveryCode;
    private double balance;
    private int points;
    private boolean admin;
    private boolean active;
    private LocalDateTime createdAt;
    private final List<Transaction> history = new ArrayList<>();

    public User(int id, String username, String mobileNumber, String password, String pin,
                String recoveryCode, double balance, int points,
                boolean admin, boolean active, LocalDateTime createdAt) {
        this.id = id;
        this.username = username;
        this.mobileNumber = mobileNumber;
        this.password = password;
        this.pin = pin;
        this.recoveryCode = recoveryCode;
        this.balance = balance;
        this.points = points;
        this.admin = admin;
        this.active = active;
        this.createdAt = createdAt;
    }

    public int getId() { return id; }
    public String getUsername() { return username; }
    public String getMobileNumber() { return mobileNumber; }
    public String getPassword() { return password; }
    public String getPin() { return pin; }
    public String getRecoveryCode() { return recoveryCode; }
    public double getBalance() { return balance; }
    public int getPoints() { return points; }
    public RewardTier getTier() { return RewardTier.fromPoints(points); }
    public boolean isAdmin() { return admin; }
    public boolean isActive() { return active; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public List<Transaction> getHistory() { return history; }

    public void setBalance(double balance) { this.balance = balance; }
    public void setUsername(String username) { this.username = username; }
    public void setMobileNumber(String mobileNumber) { this.mobileNumber = mobileNumber; }
    public void setPassword(String password) { this.password = password; }
    public void setPin(String pin) { this.pin = pin; }
    public void setRecoveryCode(String recoveryCode) { this.recoveryCode = recoveryCode; }
    public void setPoints(int points) { this.points = points; }
    public void setActive(boolean active) { this.active = active; }
}
