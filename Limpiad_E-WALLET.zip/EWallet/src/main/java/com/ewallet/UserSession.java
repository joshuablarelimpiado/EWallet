package com.ewallet;

import java.io.Serializable;

public class UserSession implements Serializable {

    private static final long serialVersionUID = 1L;

    private final int id;
    private final String username;
    private final String mobileNumber;
    private final boolean admin;

    public UserSession(User user) {
        this.id = user.getId();
        this.username = user.getUsername();
        this.mobileNumber = user.getMobileNumber();
        this.admin = user.isAdmin();
    }

    public int getId() { return id; }
    public String getUsername() { return username; }
    public String getMobileNumber() { return mobileNumber; }
    public boolean isAdmin() { return admin; }
}
