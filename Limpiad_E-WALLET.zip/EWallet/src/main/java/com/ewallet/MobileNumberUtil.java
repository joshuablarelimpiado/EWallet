package com.ewallet;

public class MobileNumberUtil {

    
    public static boolean isValid(String number) {
        return number != null && number.matches("9\\d{9}");
    }

    
    public static String formatDisplay(String number) {
        if (!isValid(number)) return number;
        return "+63 " + number.substring(0, 3) + " " + number.substring(3, 6) + " " + number.substring(6);
    }
}
