package com.ewallet;

import java.io.*;

public class SessionManager {

    private static final String SESSION_FILE = "session.dat";

    
    public static void save(User user) {
        UserSession session = new UserSession(user);
        try (ObjectOutputStream out =
                     new ObjectOutputStream(new FileOutputStream(SESSION_FILE))) {
            out.writeObject(session);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    
    public static UserSession load() {
        File file = new File(SESSION_FILE);
        if (!file.exists()) return null;

        try (ObjectInputStream in =
                     new ObjectInputStream(new FileInputStream(file))) {
            Object obj = in.readObject();
            return (obj instanceof UserSession) ? (UserSession) obj : null;
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();

            file.delete();
            return null;
        }
    }

    
    public static void clear() {
        File file = new File(SESSION_FILE);
        if (file.exists()) file.delete();
    }
}
