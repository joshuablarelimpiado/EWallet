package com.ewallet;

public enum RewardTier {
    NEW("New", 0),
    AVERAGE("Average", 10),
    VIP("VIP", 50);

    private final String label;
    private final int minPoints;

    RewardTier(String label, int minPoints) {
        this.label = label;
        this.minPoints = minPoints;
    }

    public String getLabel() { return label; }

    public static RewardTier fromPoints(int points) {
        if (points >= VIP.minPoints) return VIP;
        if (points >= AVERAGE.minPoints) return AVERAGE;
        return NEW;
    }

    
    public static int pointsToNextTier(int points) {
        RewardTier current = fromPoints(points);
        if (current == VIP) return -1;
        if (current == NEW) return AVERAGE.minPoints - points;
        return VIP.minPoints - points;
    }
}
