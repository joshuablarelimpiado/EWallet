package com.ewallet;

public class DataStore {

    private static final UserRepository userRepository = new UserRepository();
    private static final TransactionService transactionService = new TransactionService();
    private static final AdminAuditService adminAuditService = new AdminAuditService(userRepository);

    static {

        transactionService.addObserver(new ConsoleTransactionLogger());
    }

    public enum RegisterResult { SUCCESS, USERNAME_TAKEN, MOBILE_TAKEN, RESERVED_MOBILE, ERROR }

    public static void seedDefaultAdmin() {
        userRepository.seedDefaultAdmin();
    }

    public static User findUserByMobile(String mobileNumber) {
        return userRepository.findUserByMobile(mobileNumber);
    }

    public static User findUserByMobileIncludingInactive(String mobileNumber) {
        return userRepository.findUserByMobileIncludingInactive(mobileNumber);
    }

    public static User findUserByUsername(String username) {
        return userRepository.findUserByUsername(username);
    }

    public static User findUserById(int userId) {
        return userRepository.findUserById(userId);
    }

    public static java.util.List<User> findAllUsers() {
        return userRepository.findAllUsers();
    }

    public static RegisterResult registerUser(String username, String mobileNumber, String password,
                                               String pin, String recoveryCode) {
        return userRepository.registerUser(username, mobileNumber, password, pin, recoveryCode);
    }

    public static boolean isReservedMobile(String mobileNumber) {
        return userRepository.isReservedMobile(mobileNumber);
    }

    public static boolean updateUserInfo(int userId, String newUsername, String newPassword, String newPin) {
        return userRepository.updateUserInfo(userId, newUsername, newPassword, newPin);
    }

    public static boolean resetPassword(int userId, String newPassword) {
        return userRepository.resetPassword(userId, newPassword);
    }

    public static boolean deactivateUser(int userId) {
        return userRepository.deactivateUser(userId);
    }

    public static boolean reactivateUser(int userId) {
        return userRepository.reactivateUser(userId);
    }

    public static void deposit(User user, double amount) {
        transactionService.deposit(user, amount);
    }

    public static boolean withdraw(User user, double amount) {
        return transactionService.withdraw(user, amount);
    }

    public static boolean transfer(User sender, User recipient, double amount) {
        return transactionService.transfer(sender, recipient, amount);
    }

    public static Transaction findTransaction(int userId, int transactionId) {
        return transactionService.findTransaction(userId, transactionId);
    }

    public static boolean adminSetActive(int adminId, int targetUserId, boolean active) {
        return adminAuditService.adminSetActive(adminId, targetUserId, active);
    }

    public static java.util.List<String> getAdminAuditLog(int limit) {
        return adminAuditService.getAdminAuditLog(limit);
    }
}
