package com.ewallet;

public interface TransactionObserver {
    void onTransaction(User user, Transaction transaction);
}
