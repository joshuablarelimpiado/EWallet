package com.ewallet;

import java.sql.*;
import java.time.LocalDateTime;

public class UserRepository implements UserLookup {

    
    private static final RowMapper<Transaction> TRANSACTION_MAPPER = rs -> {
        Timestamp ts = rs.getTimestamp("created_at");
        LocalDateTime dateTime = ts != null ? ts.toLocalDateTime() : LocalDateTime.now();
        return new Transaction(
                rs.getInt("id"),
                rs.getString("type"),
                rs.getDouble("amount"),
                rs.getDouble("balance_after"),
                dateTime
        );
    };

    
    private static final RowMapper<User> USER_MAPPER = rs -> {
        Timestamp createdTs = rs.getTimestamp("created_at");
        LocalDateTime createdAt = createdTs != null ? createdTs.toLocalDateTime() : LocalDateTime.now();
        return new User(
                rs.getInt("id"),
                rs.getString("username"),
                rs.getString("mobile_number"),
                rs.getString("password"),
                rs.getString("pin"),
                rs.getString("recovery_code"),
                rs.getDouble("balance"),
                rs.getInt("points"),
                rs.getBoolean("is_admin"),
                rs.getBoolean("is_active"),
                createdAt
        );
    };

    private static final String ADMIN_USERNAME = "admin";
    private static final String ADMIN_MOBILE = "9000000000";
    private static final String ADMIN_PASSWORD = "admin!123";
    private static final String ADMIN_PIN = "0000";
    private static final String ADMIN_RECOVERY_CODE = "ADMIN-RECOVERY-0000";

    
    public void seedDefaultAdmin() {
        try (Connection conn = Database.connect()) {
            if (hasWorkingAdmin(conn)) {
                return;
            }

            try (PreparedStatement del = conn.prepareStatement(
                    "DELETE FROM users WHERE mobile_number = ? AND is_admin = TRUE")) {
                del.setString(1, ADMIN_MOBILE);
                del.executeUpdate();
            }
            String sql = "INSERT INTO users (username, mobile_number, password, pin, recovery_code, balance, points, is_admin, is_active) " +
                    "VALUES (?, ?, ?, ?, ?, 0, 0, TRUE, TRUE)";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, ADMIN_USERNAME);
                ps.setString(2, ADMIN_MOBILE);
                ps.setString(3, PasswordUtil.hash(ADMIN_PASSWORD));
                ps.setString(4, PasswordUtil.hash(ADMIN_PIN));
                ps.setString(5, PasswordUtil.hash(ADMIN_RECOVERY_CODE));
                ps.executeUpdate();
                System.out.println("Seeded default admin account -> username: " + ADMIN_USERNAME +
                        ", password: " + ADMIN_PASSWORD);
            }
        } catch (SQLException e) {

            Database.showConnectionError(e);
        }
    }

    
    private boolean hasWorkingAdmin(Connection conn) throws SQLException {
        String sql = "SELECT password FROM users WHERE is_admin = TRUE";
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                String storedPassword = rs.getString("password");
                if (storedPassword != null && storedPassword.startsWith("$2")) {
                    return true;
                }
            }
        }
        return false;
    }

    
    @Override
    public User findUserByMobile(String mobileNumber) {
        String sql = "SELECT * FROM users WHERE mobile_number = ? AND is_active = TRUE";
        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, mobileNumber);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                User user = mapUser(rs);
                loadHistory(conn, user);
                return user;
            }
        } catch (SQLException e) {
            Database.showConnectionError(e);
        }
        return null;
    }

    
    public User findUserByMobileIncludingInactive(String mobileNumber) {
        String sql = "SELECT * FROM users WHERE mobile_number = ?";
        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, mobileNumber);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                User user = mapUser(rs);
                loadHistory(conn, user);
                return user;
            }
        } catch (SQLException e) {
            Database.showConnectionError(e);
        }
        return null;
    }

    
    @Override
    public User findUserByUsername(String username) {
        String sql = "SELECT * FROM users WHERE username = ? AND is_active = TRUE";
        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                User user = mapUser(rs);
                loadHistory(conn, user);
                return user;
            }
        } catch (SQLException e) {
            Database.showConnectionError(e);
        }
        return null;
    }

    @Override
    public User findUserById(int userId) {
        String sql = "SELECT * FROM users WHERE id = ?";
        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                User user = mapUser(rs);
                loadHistory(conn, user);
                return user;
            }
        } catch (SQLException e) {
            Database.showConnectionError(e);
        }
        return null;
    }

    public java.util.List<User> findAllUsers() {
        java.util.List<User> users = new java.util.ArrayList<>();
        String sql = "SELECT * FROM users WHERE is_admin = FALSE ORDER BY created_at DESC";
        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                User user = mapUser(rs);
                loadHistory(conn, user);
                users.add(user);
            }
        } catch (SQLException e) {
            Database.showConnectionError(e);
        }
        return users;
    }

    
    public DataStore.RegisterResult registerUser(String username, String mobileNumber, String password,
                                                  String pin, String recoveryCode) {
        if (isReservedMobile(mobileNumber)) {
            return DataStore.RegisterResult.RESERVED_MOBILE;
        }
        String sql = "INSERT INTO users (username, mobile_number, password, pin, recovery_code, balance, points, is_admin) " +
                "VALUES (?, ?, ?, ?, ?, 0, 0, FALSE)";
        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, mobileNumber);
            ps.setString(3, PasswordUtil.hash(password));
            ps.setString(4, PasswordUtil.hash(pin));
            ps.setString(5, PasswordUtil.hash(recoveryCode));
            ps.executeUpdate();
            return DataStore.RegisterResult.SUCCESS;
        } catch (SQLIntegrityConstraintViolationException e) {

            String msg = e.getMessage() == null ? "" : e.getMessage().toLowerCase();
            if (msg.contains("mobile_number")) return DataStore.RegisterResult.MOBILE_TAKEN;
            if (msg.contains("username")) return DataStore.RegisterResult.USERNAME_TAKEN;
            return DataStore.RegisterResult.USERNAME_TAKEN;
        } catch (SQLException e) {
            Database.showConnectionError(e);
            return DataStore.RegisterResult.ERROR;
        }
    }

    
    public boolean isReservedMobile(String mobileNumber) {
        return ADMIN_MOBILE.equals(mobileNumber);
    }

    
    public boolean updateUserInfo(int userId, String newUsername, String newPassword, String newPin) {
        StringBuilder sql = new StringBuilder("UPDATE users SET ");
        java.util.List<String> sets = new java.util.ArrayList<>();
        java.util.List<Object> values = new java.util.ArrayList<>();

        if (newUsername != null && !newUsername.isBlank()) {
            sets.add("username = ?");
            values.add(newUsername);
        }
        if (newPassword != null && !newPassword.isBlank()) {
            sets.add("password = ?");
            values.add(PasswordUtil.hash(newPassword));
        }
        if (newPin != null && !newPin.isBlank()) {
            sets.add("pin = ?");
            values.add(PasswordUtil.hash(newPin));
        }
        if (sets.isEmpty()) return true;

        sql.append(String.join(", ", sets)).append(" WHERE id = ?");
        values.add(userId);

        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            for (int i = 0; i < values.size(); i++) {
                ps.setObject(i + 1, values.get(i));
            }
            ps.executeUpdate();
            return true;
        } catch (SQLIntegrityConstraintViolationException e) {
            return false;
        } catch (SQLException e) {
            Database.showConnectionError(e);
            return false;
        }
    }

    
    public boolean resetPassword(int userId, String newPassword) {
        String sql = "UPDATE users SET password = ? WHERE id = ?";
        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, PasswordUtil.hash(newPassword));
            ps.setInt(2, userId);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            Database.showConnectionError(e);
            return false;
        }
    }

    
    public boolean deactivateUser(int userId) {
        String sql = "UPDATE users SET is_active = FALSE WHERE id = ?";
        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            Database.showConnectionError(e);
            return false;
        }
    }

    public boolean reactivateUser(int userId) {
        String sql = "UPDATE users SET is_active = TRUE WHERE id = ?";
        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            Database.showConnectionError(e);
            return false;
        }
    }

    private void loadHistory(Connection conn, User user) throws SQLException {
        String sql = "SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC, id DESC";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, user.getId());
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                user.getHistory().add(mapTransaction(rs));
            }
        }
    }

    
    private Transaction mapTransaction(ResultSet rs) throws SQLException {
        return TRANSACTION_MAPPER.map(rs);
    }

    
    private User mapUser(ResultSet rs) throws SQLException {
        return USER_MAPPER.map(rs);
    }
}
