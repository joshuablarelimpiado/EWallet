package com.ewallet;

import javafx.scene.Scene;
import javafx.scene.layout.Region;
import javafx.stage.Stage;

public class SceneManager {

    private static Stage stage;
    private static Scene scene;

    public static void init(Stage primaryStage) {
        stage = primaryStage;
    }

    public static void showLogin() {
        setRoot(new LoginView().getView(), "E-Wallet - Login", 420, 520);
    }

    public static void showRegister() {
        setRoot(new RegisterView().getView(), "E-Wallet - Register", 440, 640);
    }

    public static void showForgotPassword() {
        setRoot(new ForgotPasswordView().getView(), "E-Wallet - Reset Password", 420, 560);
    }

    
    public static void showPinUnlock(String mobileNumber) {
        setRoot(new PinUnlockView(mobileNumber).getView(), "E-Wallet - Unlock", 420, 480);
    }

    public static void showDashboard(User user) {
        setRoot(new DashboardView(user).getView(), "E-Wallet - " + user.getUsername(), 680, 600);
    }

    public static void showSettings(User user) {
        setRoot(new SettingsView(user).getView(), "E-Wallet - Settings", 680, 600);
    }

    public static void showTransactionDetail(User user, Transaction transaction) {
        setRoot(new TransactionDetailView(user, transaction).getView(), "E-Wallet - Receipt", 680, 600);
    }

    public static void showAdminUserDetail(User admin, User targetUser) {
        setRoot(new AdminUserDetailView(admin, targetUser).getView(), "E-Wallet - " + targetUser.getUsername(), 680, 600);
    }

    public static Scene getScene() {
        return scene;
    }

    private static void setRoot(Region root, String title, double w, double h) {
        if (scene == null) {
            scene = new Scene(root, w, h);
            ThemeManager.applyTo(scene);
            stage.setScene(scene);
        } else {
            scene.setRoot(root);
        }
        stage.setTitle(title);
    }
}
