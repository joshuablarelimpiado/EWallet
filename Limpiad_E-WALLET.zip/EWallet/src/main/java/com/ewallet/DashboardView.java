package com.ewallet;

import javafx.animation.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.util.Duration;

import java.util.Map;

public class DashboardView {

    private final BorderPane root = new BorderPane();
    private final User user;

    private Label balanceAmount;
    private Label pointsLabel;
    private ListView<Transaction> historyList;
    private Label statusLabel;
    private StackPane balanceCardStack;
    private Text coin;
    private RotateTransition coinSpin;

    public DashboardView(User user) {
        this.user = user;
        root.getStyleClass().add("root");
        root.setPadding(new Insets(24));

        root.setTop(buildHeader());
        root.setCenter(user.isAdmin() ? buildAdminCenter() : buildCenter());

        BorderPane.setMargin(root.getCenter(), new Insets(20, 0, 0, 0));
    }

    private HBox buildHeader() {
        String label = user.isAdmin() ? "Admin: " + user.getUsername() : "Hi, " + user.getUsername();
        Label usernameLabel = new Label(label);
        usernameLabel.getStyleClass().add("username-label");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button themeToggle = ThemeToggleButton.create();

        Label settings = new Label("Settings");
        settings.getStyleClass().add("logout-label");
        settings.setOnMouseClicked(e -> SceneManager.showSettings(user));

        Label logout = new Label("Log out");
        logout.getStyleClass().add("logout-label");
        logout.setOnMouseClicked(e -> {
            SessionManager.clear();
            SceneManager.showLogin();
        });

        HBox header = user.isAdmin()
                ? new HBox(14, usernameLabel, spacer, themeToggle, logout)
                : new HBox(14, usernameLabel, spacer, themeToggle, settings, logout);
        header.setAlignment(Pos.CENTER_LEFT);
        return header;
    }

    private VBox buildAdminCenter() {
        Label sectionLabel = new Label("All Users");
        sectionLabel.getStyleClass().add("section-label");

        Label note = new Label("Activate or deactivate accounts, and view transaction history. Balances cannot be edited directly.");
        note.getStyleClass().add("subtitle-label");
        note.setWrapText(true);

        ListView<User> userList = new ListView<>();
        userList.getStyleClass().add("history-list");
        userList.setPlaceholder(new Label("No registered users yet."));
        userList.setCellFactory(lv -> new AdminUserCell());
        userList.getItems().addAll(DataStore.findAllUsers());
        VBox.setVgrow(userList, Priority.ALWAYS);

        Label auditLabel = new Label("Recent Admin Activity");
        auditLabel.getStyleClass().add("section-label");

        ListView<String> auditList = new ListView<>();
        auditList.getStyleClass().add("history-list");
        auditList.setPlaceholder(new Label("No admin actions yet."));
        auditList.setPrefHeight(140);
        auditList.getItems().addAll(DataStore.getAdminAuditLog(20));

        VBox center = new VBox(10, sectionLabel, note, userList, auditLabel, auditList);
        VBox.setVgrow(userList, Priority.ALWAYS);
        return center;
    }

    
    private class AdminUserCell extends ListCell<User> {
        @Override
        protected void updateItem(User u, boolean empty) {
            super.updateItem(u, empty);
            if (empty || u == null) {
                setGraphic(null);
                return;
            }

            Label info = new Label(String.format("%-20s %s%,.2f    Tier: %-8s (%d pts)    %s",
                    u.getUsername(), "\u20B1", u.getBalance(), u.getTier().getLabel(), u.getPoints(),
                    u.isActive() ? "Active" : "Deactivated"));
            info.getStyleClass().add(u.isActive() ? "success-label" : "error-label");

            Button viewBtn = new Button("View History");
            viewBtn.getStyleClass().add("btn-secondary");
            viewBtn.setOnAction(e -> SceneManager.showAdminUserDetail(user, u));

            Button toggleBtn = new Button(u.isActive() ? "Deactivate" : "Activate");
            toggleBtn.getStyleClass().add(u.isActive() ? "btn-secondary" : "btn-primary");
            toggleBtn.setOnAction(e -> confirmToggle(u));

            Region spacer = new Region();
            HBox.setHgrow(spacer, Priority.ALWAYS);

            HBox row = new HBox(10, info, spacer, viewBtn, toggleBtn);
            row.setAlignment(Pos.CENTER_LEFT);
            setGraphic(row);
        }

        private void confirmToggle(User target) {
            boolean deactivating = target.isActive();
            Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
            confirm.setTitle(deactivating ? "Deactivate Account" : "Activate Account");
            confirm.setHeaderText(null);
            confirm.setContentText((deactivating ? "Deactivate " : "Reactivate ") + target.getUsername() + "'s account?");
            confirm.showAndWait().ifPresent(choice -> {
                if (choice == ButtonType.OK) {
                    DataStore.adminSetActive(user.getId(), target.getId(), !deactivating);
                    root.setCenter(buildAdminCenter());
                }
            });
        }
    }

    private VBox buildCenter() {
        StackPane balanceCard = buildBalanceCard();
        HBox actions = buildActions();
        VBox historySection = buildHistorySection();

        VBox center = new VBox(20, balanceCard, actions, historySection);
        VBox.setVgrow(historySection, Priority.ALWAYS);
        return center;
    }

    private StackPane buildBalanceCard() {
        Label label = new Label("Available Balance");
        label.getStyleClass().add("balance-label");

        balanceAmount = new Label(formatMoney(user.getBalance()));
        balanceAmount.getStyleClass().add("balance-amount");

        pointsLabel = new Label(tierText());
        pointsLabel.getStyleClass().add("subtitle-label");

        coin = new Text("\u20B1");
        coin.setFont(Font.font("Segoe UI", FontWeight.BOLD, 24));
        coin.setFill(Color.web("#0B1024"));

        Circle coinBase = new Circle(20);
        coinBase.setFill(Color.web("#4FE3C1"));
        coinBase.setStroke(Color.web("#3FD1AF"));
        coinBase.setStrokeWidth(2);

        StackPane coinBadge = new StackPane(coinBase, coin);
        coinBadge.setMaxSize(40, 40);

        coinSpin = new RotateTransition(Duration.seconds(4), coinBadge);
        coinSpin.setAxis(javafx.scene.transform.Rotate.Y_AXIS);
        coinSpin.setFromAngle(0);
        coinSpin.setToAngle(360);
        coinSpin.setCycleCount(Animation.INDEFINITE);
        coinSpin.setInterpolator(Interpolator.LINEAR);
        coinSpin.play();

        HBox amountRow = new HBox(12, balanceAmount, coinBadge);
        amountRow.setAlignment(Pos.CENTER_LEFT);

        VBox textStack = new VBox(6, label, amountRow, pointsLabel);

        VBox card = new VBox(6, textStack);
        card.getStyleClass().add("balance-card");

        FadeTransition glow = new FadeTransition(Duration.seconds(2.2), card);
        glow.setFromValue(1.0);
        glow.setToValue(0.88);
        glow.setAutoReverse(true);
        glow.setCycleCount(Animation.INDEFINITE);
        glow.play();

        balanceCardStack = new StackPane(card);
        balanceCardStack.setAlignment(Pos.TOP_RIGHT);
        return balanceCardStack;
    }

    private String tierText() {
        int toNext = RewardTier.pointsToNextTier(user.getPoints());
        String tier = user.getTier().getLabel() + " Tier \u00b7 " + user.getPoints() + " pts";
        if (toNext > 0) {
            tier += "  (" + toNext + " pts to next tier)";
        }
        return tier;
    }

    private void popAmount(double amount) {
        String text = (amount >= 0 ? "+" : "-") + formatMoney(Math.abs(amount));
        Label popup = new Label(text);
        popup.getStyleClass().add(amount >= 0 ? "success-label" : "error-label");
        popup.setStyle(popup.getStyle() + "; -fx-font-size: 16px; -fx-font-weight: bold;");
        popup.setTranslateY(0);
        popup.setOpacity(1);
        StackPane.setMargin(popup, new Insets(10, 16, 0, 0));

        balanceCardStack.getChildren().add(popup);

        TranslateTransition rise = new TranslateTransition(Duration.seconds(1.2), popup);
        rise.setByY(-30);

        FadeTransition fade = new FadeTransition(Duration.seconds(1.2), popup);
        fade.setFromValue(1);
        fade.setToValue(0);

        ParallelTransition combo = new ParallelTransition(rise, fade);
        combo.setOnFinished(e -> balanceCardStack.getChildren().remove(popup));
        combo.play();

        if (coinSpin != null) {
            coinSpin.setRate(4);
            PauseTransition settle = new PauseTransition(Duration.seconds(1));
            settle.setOnFinished(e -> coinSpin.setRate(1));
            settle.play();
        }
    }

    private HBox buildActions() {
        Button depositBtn = new Button("Cash In");
        depositBtn.getStyleClass().add("btn-primary");
        depositBtn.setOnAction(e -> showAmountDialog("Cash In", "Amount to deposit:", amount -> {
            DataStore.deposit(user, amount);
            refresh("Cashed in " + formatMoney(amount) + ".", amount);
        }));

        Button withdrawBtn = new Button("Cash Out");
        withdrawBtn.getStyleClass().add("btn-secondary");
        withdrawBtn.setOnAction(e -> showAmountDialog("Cash Out", "Amount to withdraw:", amount -> {
            if (DataStore.withdraw(user, amount)) {
                refresh("Cashed out " + formatMoney(amount) + ".", -amount);
            } else {
                statusLabel.getStyleClass().setAll("error-label");
                statusLabel.setText("Insufficient balance.");
            }
        }));

        Button transferBtn = new Button("Transfer");
        transferBtn.getStyleClass().add("btn-secondary");
        transferBtn.setOnAction(e -> showTransferDialog());

        HBox actions = new HBox(12, depositBtn, withdrawBtn, transferBtn);
        actions.setAlignment(Pos.CENTER_LEFT);
        return actions;
    }

    private VBox buildHistorySection() {
        Label sectionLabel = new Label("Transaction History");
        sectionLabel.getStyleClass().add("section-label");

        statusLabel = new Label();
        statusLabel.getStyleClass().add("success-label");

        historyList = new ListView<>();
        historyList.getStyleClass().add("history-list");
        historyList.setPlaceholder(new Label("No transactions yet."));
        historyList.setCellFactory(lv -> new TransactionCell());
        loadHistory();
        VBox.setVgrow(historyList, Priority.ALWAYS);

        Label hint = new Label("Click a transaction to view its receipt.");
        hint.getStyleClass().add("subtitle-label");
        hint.setStyle("-fx-font-size: 11px;");

        VBox section = new VBox(8, sectionLabel, statusLabel, historyList, hint);
        return section;
    }

    
    private class TransactionCell extends ListCell<Transaction> {
        @Override
        protected void updateItem(Transaction t, boolean empty) {
            super.updateItem(t, empty);
            if (empty || t == null) {
                setText(null);
                setOnMouseClicked(null);
                return;
            }
            setText(t.getDisplay());
            setOnMouseClicked(e -> SceneManager.showTransactionDetail(user, t));
        }
    }

    private void loadHistory() {
        historyList.getItems().clear();
        User refreshed = DataStore.findUserById(user.getId());
        if (refreshed == null) return;
        historyList.getItems().addAll(refreshed.getHistory());
    }

    private void refresh(String message, double delta) {
        User refreshed = DataStore.findUserById(user.getId());
        if (refreshed != null) {
            user.setBalance(refreshed.getBalance());
            user.setPoints(refreshed.getPoints());
        }
        balanceAmount.setText(formatMoney(user.getBalance()));
        pointsLabel.setText(tierText());
        loadHistory();
        statusLabel.getStyleClass().setAll("success-label");
        statusLabel.setText(message);
        popAmount(delta);
    }

    private void showAmountDialog(String title, String prompt, java.util.function.DoubleConsumer onConfirm) {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle(title);
        dialog.setHeaderText(null);
        dialog.setContentText(prompt);
        dialog.showAndWait().ifPresent(input -> {
            try {
                double amount = Double.parseDouble(input.trim());
                if (amount <= 0) {
                    statusLabel.getStyleClass().setAll("error-label");
                    statusLabel.setText("Enter an amount greater than zero.");
                    return;
                }
                onConfirm.accept(amount);
            } catch (NumberFormatException ex) {
                statusLabel.getStyleClass().setAll("error-label");
                statusLabel.setText("Please enter a valid number.");
            }
        });
    }

    private void showTransferDialog() {
        Dialog<Void> dialog = new Dialog<>();
        dialog.setTitle("Transfer Funds");
        dialog.setHeaderText(null);

        ButtonType sendButtonType = new ButtonType("Send", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(sendButtonType, ButtonType.CANCEL);

        ComboBox<String> recipientBox = new ComboBox<>();
        recipientBox.setEditable(true);
        recipientBox.setPromptText("Select or type recipient username");
        recipientBox.setMaxWidth(Double.MAX_VALUE);
        recipientBox.getStyleClass().add("field");

        Map<String, User> byUsername = new java.util.HashMap<>();
        for (User u : DataStore.findAllUsers()) {
            if (u.isActive() && !u.getUsername().equalsIgnoreCase(user.getUsername())) {
                recipientBox.getItems().add(u.getUsername());
                byUsername.put(u.getUsername().toLowerCase(), u);
            }
        }

        TextField amountField = new TextField();
        amountField.setPromptText("Amount");

        VBox content = new VBox(10, recipientBox, amountField);
        content.setPadding(new Insets(10));
        dialog.getDialogPane().setContent(content);

        Button sendButton = (Button) dialog.getDialogPane().lookupButton(sendButtonType);
        sendButton.setDefaultButton(true);

        dialog.setResultConverter(bt -> {
            if (bt == sendButtonType) {
                String recipientName = recipientBox.getValue();
                String amountText = amountField.getText().trim();

                if (recipientName == null || recipientName.isEmpty() || amountText.isEmpty()) {
                    statusLabel.getStyleClass().setAll("error-label");
                    statusLabel.setText("Please select a recipient and enter an amount.");
                    return null;
                }
                if (recipientName.equalsIgnoreCase(user.getUsername())) {
                    statusLabel.getStyleClass().setAll("error-label");
                    statusLabel.setText("You can't transfer to yourself.");
                    return null;
                }

                User recipient = byUsername.get(recipientName.toLowerCase());
                if (recipient == null) {
                    statusLabel.getStyleClass().setAll("error-label");
                    statusLabel.setText("Recipient not found.");
                    return null;
                }

                try {
                    double amount = Double.parseDouble(amountText);
                    if (amount <= 0) {
                        statusLabel.getStyleClass().setAll("error-label");
                        statusLabel.setText("Enter an amount greater than zero.");
                        return null;
                    }
                    if (DataStore.transfer(user, recipient, amount)) {
                        refresh("Sent " + formatMoney(amount) + " to " + recipient.getUsername() + ".", -amount);
                    } else {
                        statusLabel.getStyleClass().setAll("error-label");
                        statusLabel.setText("Insufficient balance.");
                    }
                } catch (NumberFormatException ex) {
                    statusLabel.getStyleClass().setAll("error-label");
                    statusLabel.setText("Please enter a valid number.");
                }
            }
            return null;
        });

        dialog.showAndWait();
    }

    private String formatMoney(double amount) {
        return String.format("\u20B1%,.2f", amount);
    }

    public BorderPane getView() {
        return root;
    }
}
