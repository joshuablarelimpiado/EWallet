package com.ewallet;

public interface UserLookup {
    User findUserByMobile(String mobileNumber);
    User findUserByUsername(String username);
    User findUserById(int userId);
}
