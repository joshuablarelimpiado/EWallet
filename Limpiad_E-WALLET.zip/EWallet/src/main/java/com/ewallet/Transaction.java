package com.ewallet;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Transaction {
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("MMM dd, HH:mm");
    private static final DateTimeFormatter FULL_FMT = DateTimeFormatter.ofPattern("MMMM d, yyyy 'at' h:mm a");

    private final int id;
    private final String type;
    private final double amount;
    private final double balanceAfter;
    private final LocalDateTime timestamp;

    public Transaction(int id, String type, double amount, double balanceAfter, LocalDateTime timestamp) {
        this.id = id;
        this.type = type;
        this.amount = amount;
        this.balanceAfter = balanceAfter;
        this.timestamp = timestamp;
    }

    public int getId() { return id; }
    public String getType() { return type; }
    public double getAmount() { return amount; }
    public double getBalanceAfter() { return balanceAfter; }
    public LocalDateTime getTimestamp() { return timestamp; }

    public String getDisplay() {
        String sign = amount >= 0 ? "+" : "-";
        return String.format("%-22s %s%s%.2f    (Balance: %s%.2f)    %s",
                type, sign, "\u20B1", Math.abs(amount), "\u20B1", balanceAfter, timestamp.format(FMT));
    }

    
    public String getReceiptText() {
        String sign = amount >= 0 ? "+" : "-";
        return "Receipt #" + id + "\n\n"
                + "Type: " + type + "\n"
                + "Amount: " + sign + "\u20B1" + String.format("%,.2f", Math.abs(amount)) + "\n"
                + "Balance after: \u20B1" + String.format("%,.2f", balanceAfter) + "\n"
                + "Date: " + timestamp.format(FULL_FMT);
    }

    @Override
    public String toString() {
        return getDisplay();
    }
}
