package com.ewallet;

import java.time.LocalDateTime;

public class TransactionFactory {

    public static Transaction createDeposit(int id, double amount, double balanceAfter, LocalDateTime timestamp) {
        return new Transaction(id, "Cash In (Deposit)", amount, balanceAfter, timestamp);
    }

    public static Transaction createWithdrawal(int id, double amount, double balanceAfter, LocalDateTime timestamp) {
        return new Transaction(id, "Cash Out (Withdraw)", -amount, balanceAfter, timestamp);
    }

    public static Transaction createTransferSent(int id, double amount, double balanceAfter,
                                                  String recipientUsername, LocalDateTime timestamp) {
        return new Transaction(id, "Sent to " + recipientUsername, -amount, balanceAfter, timestamp);
    }

    public static Transaction createTransferReceived(int id, double amount, double balanceAfter,
                                                       String senderUsername, LocalDateTime timestamp) {
        return new Transaction(id, "Received from " + senderUsername, amount, balanceAfter, timestamp);
    }
}
