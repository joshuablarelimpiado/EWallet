package com.ewallet;

public class ConsoleTransactionLogger implements TransactionObserver {

    @Override
    public void onTransaction(User user, Transaction transaction) {
        System.out.println("[TX LOG] " + user.getUsername() + " -> " + transaction.getDisplay());
    }
}
