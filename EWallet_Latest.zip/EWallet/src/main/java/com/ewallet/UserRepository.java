package com.ewallet;

import java.sql.*;
import java.time.LocalDateTime;

/**
 * Owns everything about reading and writing USER RECORDS: lookups,
 * registration, account settings, activation/deactivation.
 *
 * This is one of three classes DataStore used to be (the others are
 * TransactionService for wallet/money movement, and AdminAuditService for
 * the admin audit log). Splitting them up means each class now has exactly
 * one reason to change: this one changes only when how we store/find users
 * changes, not when reward-point math or audit-log formatting changes.
 *
 * Implements UserLookup so callers that only need to *find* a user (like
 * LoginView, PinUnlockView) can depend on that narrower interface instead
 * of this whole class.
 */
public class UserRepository implements UserLookup {

    // Default admin credentials used only when no admin account exists yet.
    // Change ADMIN_PASSWORD here if you want a different default password;
    // it will be re-hashed automatically the next time the app starts.
    private static final String ADMIN_USERNAME = "admin";
    private static final String ADMIN_MOBILE = "9000000000";
    private static final String ADMIN_PASSWORD = "admin!123";
    private static final String ADMIN_PIN = "0000";
    private static final String ADMIN_RECOVERY_CODE = "ADMIN-RECOVERY-0000";

    // ---------------------------------------------------------------
    // Startup seeding
    // ---------------------------------------------------------------

    /**
     * Ensures a working admin account exists, called once on app startup.
     * schema.sql seeds a placeholder admin row with plaintext values (since
     * SQL alone can't call BCrypt), which can never pass PasswordUtil.matches().
     * This replaces that placeholder with a properly hashed admin account,
     * or does nothing if a real admin already exists.
     */
    public void seedDefaultAdmin() {
        try (Connection conn = Database.connect()) {
            if (hasWorkingAdmin(conn)) {
                return;
            }
            // Remove the unusable placeholder seed row from schema.sql, if present.
            try (PreparedStatement del = conn.prepareStatement(
                    "DELETE FROM users WHERE mobile_number = ? AND is_admin = TRUE")) {
                del.setString(1, ADMIN_MOBILE);
                del.executeUpdate();
            }
            String sql = "INSERT INTO users (username, mobile_number, password, pin, recovery_code, balance, points, is_admin, is_active) " +
                    "VALUES (?, ?, ?, ?, ?, 0, 0, TRUE, TRUE)";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, ADMIN_USERNAME);
                ps.setString(2, ADMIN_MOBILE);
                ps.setString(3, PasswordUtil.hash(ADMIN_PASSWORD));
                ps.setString(4, PasswordUtil.hash(ADMIN_PIN));
                ps.setString(5, PasswordUtil.hash(ADMIN_RECOVERY_CODE));
                ps.executeUpdate();
                System.out.println("Seeded default admin account -> username: " + ADMIN_USERNAME +
                        ", password: " + ADMIN_PASSWORD);
            }
        } catch (SQLException e) {
            // Non-fatal: if seeding fails (e.g. DB not reachable yet), the app
            // still starts and the existing login error handling takes over.
            Database.showConnectionError(e);
        }
    }

    /** True if a row already exists with is_admin = TRUE and a real (bcrypt) password. */
    private boolean hasWorkingAdmin(Connection conn) throws SQLException {
        String sql = "SELECT password FROM users WHERE is_admin = TRUE";
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                String storedPassword = rs.getString("password");
                if (storedPassword != null && storedPassword.startsWith("$2")) {
                    return true; // looks like a real bcrypt hash
                }
            }
        }
        return false;
    }

    // ---------------------------------------------------------------
    // Lookups
    // ---------------------------------------------------------------

    /** Login lookup: by mobile number, active accounts only. */
    @Override
    public User findUserByMobile(String mobileNumber) {
        String sql = "SELECT * FROM users WHERE mobile_number = ? AND is_active = TRUE";
        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, mobileNumber);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                User user = mapUser(rs);
                loadHistory(conn, user);
                return user;
            }
        } catch (SQLException e) {
            Database.showConnectionError(e);
        }
        return null;
    }

    /**
     * Looks up a user by mobile number regardless of active status — used
     * for the forgot-password flow, where a deactivated user shouldn't be
     * able to reset their way back in, so callers must check isActive().
     */
    public User findUserByMobileIncludingInactive(String mobileNumber) {
        String sql = "SELECT * FROM users WHERE mobile_number = ?";
        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, mobileNumber);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                User user = mapUser(rs);
                loadHistory(conn, user);
                return user;
            }
        } catch (SQLException e) {
            Database.showConnectionError(e);
        }
        return null;
    }

    /** Login lookup: by username, active accounts only. */
    @Override
    public User findUserByUsername(String username) {
        String sql = "SELECT * FROM users WHERE username = ? AND is_active = TRUE";
        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                User user = mapUser(rs);
                loadHistory(conn, user);
                return user;
            }
        } catch (SQLException e) {
            Database.showConnectionError(e);
        }
        return null;
    }

    @Override
    public User findUserById(int userId) {
        String sql = "SELECT * FROM users WHERE id = ?";
        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                User user = mapUser(rs);
                loadHistory(conn, user);
                return user;
            }
        } catch (SQLException e) {
            Database.showConnectionError(e);
        }
        return null;
    }

    public java.util.List<User> findAllUsers() {
        java.util.List<User> users = new java.util.ArrayList<>();
        String sql = "SELECT * FROM users WHERE is_admin = FALSE ORDER BY created_at DESC";
        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                User user = mapUser(rs);
                loadHistory(conn, user);
                users.add(user);
            }
        } catch (SQLException e) {
            Database.showConnectionError(e);
        }
        return users;
    }

    // ---------------------------------------------------------------
    // Registration
    // ---------------------------------------------------------------

    /**
     * Registers a new user. Relies on the database's UNIQUE constraints on
     * username and mobile_number as the real source of truth (catching the
     * SQLIntegrityConstraintViolationException) rather than a check-then-
     * insert, which would leave a race window between two simultaneous
     * registrations of the same username/number.
     */
    public DataStore.RegisterResult registerUser(String username, String mobileNumber, String password,
                                                  String pin, String recoveryCode) {
        if (isReservedMobile(mobileNumber)) {
            return DataStore.RegisterResult.RESERVED_MOBILE;
        }
        String sql = "INSERT INTO users (username, mobile_number, password, pin, recovery_code, balance, points, is_admin) " +
                "VALUES (?, ?, ?, ?, ?, 0, 0, FALSE)";
        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, mobileNumber);
            ps.setString(3, PasswordUtil.hash(password));
            ps.setString(4, PasswordUtil.hash(pin));
            ps.setString(5, PasswordUtil.hash(recoveryCode));
            ps.executeUpdate();
            return DataStore.RegisterResult.SUCCESS;
        } catch (SQLIntegrityConstraintViolationException e) {
            // Unique constraint hit: figure out which one, best-effort.
            String msg = e.getMessage() == null ? "" : e.getMessage().toLowerCase();
            if (msg.contains("mobile_number")) return DataStore.RegisterResult.MOBILE_TAKEN;
            if (msg.contains("username")) return DataStore.RegisterResult.USERNAME_TAKEN;
            return DataStore.RegisterResult.USERNAME_TAKEN;
        } catch (SQLException e) {
            Database.showConnectionError(e);
            return DataStore.RegisterResult.ERROR;
        }
    }

    /** True if this mobile number is reserved for the system admin account and can't be self-registered. */
    public boolean isReservedMobile(String mobileNumber) {
        return ADMIN_MOBILE.equals(mobileNumber);
    }

    // ---------------------------------------------------------------
    // Account settings
    // ---------------------------------------------------------------

    /**
     * Updates username/password/pin for a user. Pass null (or blank) for any
     * field you don't want to change. Password and PIN are re-hashed here.
     */
    public boolean updateUserInfo(int userId, String newUsername, String newPassword, String newPin) {
        StringBuilder sql = new StringBuilder("UPDATE users SET ");
        java.util.List<String> sets = new java.util.ArrayList<>();
        java.util.List<Object> values = new java.util.ArrayList<>();

        if (newUsername != null && !newUsername.isBlank()) {
            sets.add("username = ?");
            values.add(newUsername);
        }
        if (newPassword != null && !newPassword.isBlank()) {
            sets.add("password = ?");
            values.add(PasswordUtil.hash(newPassword));
        }
        if (newPin != null && !newPin.isBlank()) {
            sets.add("pin = ?");
            values.add(PasswordUtil.hash(newPin));
        }
        if (sets.isEmpty()) return true; // nothing to change

        sql.append(String.join(", ", sets)).append(" WHERE id = ?");
        values.add(userId);

        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            for (int i = 0; i < values.size(); i++) {
                ps.setObject(i + 1, values.get(i));
            }
            ps.executeUpdate();
            return true;
        } catch (SQLIntegrityConstraintViolationException e) {
            return false; // username taken
        } catch (SQLException e) {
            Database.showConnectionError(e);
            return false;
        }
    }

    /** Resets a user's password directly, used by the forgot-password flow after recovery code verification. */
    public boolean resetPassword(int userId, String newPassword) {
        String sql = "UPDATE users SET password = ? WHERE id = ?";
        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, PasswordUtil.hash(newPassword));
            ps.setInt(2, userId);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            Database.showConnectionError(e);
            return false;
        }
    }

    /**
     * Soft delete: marks the account inactive instead of removing the row.
     * Keeps transaction history and referential integrity intact; an admin
     * can reactivate the account later if needed.
     */
    public boolean deactivateUser(int userId) {
        String sql = "UPDATE users SET is_active = FALSE WHERE id = ?";
        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            Database.showConnectionError(e);
            return false;
        }
    }

    public boolean reactivateUser(int userId) {
        String sql = "UPDATE users SET is_active = TRUE WHERE id = ?";
        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            Database.showConnectionError(e);
            return false;
        }
    }

    // ---------------------------------------------------------------
    // Internal helpers
    // ---------------------------------------------------------------

    private void loadHistory(Connection conn, User user) throws SQLException {
        String sql = "SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC, id DESC";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, user.getId());
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                user.getHistory().add(mapTransaction(rs));
            }
        }
    }

    private Transaction mapTransaction(ResultSet rs) throws SQLException {
        Timestamp ts = rs.getTimestamp("created_at");
        LocalDateTime dateTime = ts != null ? ts.toLocalDateTime() : LocalDateTime.now();
        return new Transaction(
                rs.getInt("id"),
                rs.getString("type"),
                rs.getDouble("amount"),
                rs.getDouble("balance_after"),
                dateTime
        );
    }

    private User mapUser(ResultSet rs) throws SQLException {
        Timestamp createdTs = rs.getTimestamp("created_at");
        LocalDateTime createdAt = createdTs != null ? createdTs.toLocalDateTime() : LocalDateTime.now();
        return new User(
                rs.getInt("id"),
                rs.getString("username"),
                rs.getString("mobile_number"),
                rs.getString("password"),
                rs.getString("pin"),
                rs.getString("recovery_code"),
                rs.getDouble("balance"),
                rs.getInt("points"),
                rs.getBoolean("is_admin"),
                rs.getBoolean("is_active"),
                createdAt
        );
    }
}
