package com.ewallet;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

public class TransactionDetailView {

    private final BorderPane root = new BorderPane();

    public TransactionDetailView(User user, Transaction transaction) {
        root.getStyleClass().add("root");
        root.setPadding(new Insets(24));

        root.setTop(buildHeader(user));
        root.setCenter(buildReceipt(transaction));
        BorderPane.setMargin(root.getCenter(), new Insets(20, 0, 0, 0));
    }

    private HBox buildHeader(User user) {
        Label title = new Label("Transaction Receipt");
        title.getStyleClass().add("username-label");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Label back = new Label("Back to Dashboard");
        back.getStyleClass().add("logout-label");
        back.setOnMouseClicked(e -> SceneManager.showDashboard(user));

        HBox header = new HBox(14, title, spacer, back);
        header.setAlignment(Pos.CENTER_LEFT);
        return header;
    }

    private VBox buildReceipt(Transaction t) {
        VBox card = new VBox(10);
        card.getStyleClass().add("balance-card");
        card.setMaxWidth(420);
        card.setPadding(new Insets(24));

        Label typeLabel = new Label(t.getType());
        typeLabel.getStyleClass().add("section-label");

        String sign = t.getAmount() >= 0 ? "+" : "-";
        Label amountLabel = new Label(sign + "\u20B1" + String.format("%,.2f", Math.abs(t.getAmount())));
        amountLabel.getStyleClass().add("balance-amount");
        amountLabel.getStyleClass().add(t.getAmount() >= 0 ? "success-label" : "error-label");

        Label balanceLabel = new Label("Balance after: \u20B1" + String.format("%,.2f", t.getBalanceAfter()));
        balanceLabel.getStyleClass().add("subtitle-label");

        Label dateLabel = new Label(t.getTimestamp().format(
                java.time.format.DateTimeFormatter.ofPattern("MMMM d, yyyy 'at' h:mm a")));
        dateLabel.getStyleClass().add("subtitle-label");

        Label idLabel = new Label("Receipt #" + t.getId());
        idLabel.getStyleClass().add("subtitle-label");
        idLabel.setStyle("-fx-font-size: 11px;");

        card.getChildren().addAll(typeLabel, amountLabel, balanceLabel, dateLabel, idLabel);

        VBox center = new VBox(20, card);
        center.setAlignment(Pos.TOP_CENTER);
        return center;
    }

    public BorderPane getView() {
        return root;
    }
}
