package com.ewallet;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

public class AdminUserDetailView {

    private final BorderPane root = new BorderPane();

    public AdminUserDetailView(User admin, User targetUser) {
        root.getStyleClass().add("root");
        root.setPadding(new Insets(24));

        root.setTop(buildHeader(admin));
        root.setCenter(buildCenter(targetUser));
        BorderPane.setMargin(root.getCenter(), new Insets(20, 0, 0, 0));
    }

    private HBox buildHeader(User admin) {
        Label title = new Label("User Details");
        title.getStyleClass().add("username-label");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Label back = new Label("Back to Admin Dashboard");
        back.getStyleClass().add("logout-label");
        back.setOnMouseClicked(e -> SceneManager.showDashboard(admin));

        HBox header = new HBox(14, title, spacer, back);
        header.setAlignment(Pos.CENTER_LEFT);
        return header;
    }

    private VBox buildCenter(User targetUser) {
        Label nameLabel = new Label(targetUser.getUsername());
        nameLabel.getStyleClass().add("section-label");

        Label infoLabel = new Label(String.format(
                "Mobile: %s    Balance: \u20B1%,.2f    Tier: %s (%d pts)    Status: %s",
                MobileNumberUtil.formatDisplay(targetUser.getMobileNumber()),
                targetUser.getBalance(),
                targetUser.getTier().getLabel(),
                targetUser.getPoints(),
                targetUser.isActive() ? "Active" : "Deactivated"));
        infoLabel.getStyleClass().add("subtitle-label");
        infoLabel.setWrapText(true);

        Label createdLabel = new Label("Account created: " +
                targetUser.getCreatedAt().format(java.time.format.DateTimeFormatter.ofPattern("MMMM d, yyyy 'at' h:mm a")));
        createdLabel.getStyleClass().add("subtitle-label");

        Label historyLabel = new Label("Transaction History (read-only)");
        historyLabel.getStyleClass().add("section-label");

        ListView<String> historyList = new ListView<>();
        historyList.getStyleClass().add("history-list");
        historyList.setPlaceholder(new Label("No transactions yet."));
        for (Transaction t : targetUser.getHistory()) {
            historyList.getItems().add(t.getDisplay());
        }
        VBox.setVgrow(historyList, Priority.ALWAYS);

        VBox center = new VBox(10, nameLabel, infoLabel, createdLabel, historyLabel, historyList);
        VBox.setVgrow(historyList, Priority.ALWAYS);
        return center;
    }

    public BorderPane getView() {
        return root;
    }
}
