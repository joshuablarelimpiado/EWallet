package com.ewallet;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

public class PinUnlockView {

    private final StackPane root = new StackPane();

    /** @param mobileNumber the stored session identifier (mobile number, not username) */
    public PinUnlockView(String mobileNumber) {
        root.getStyleClass().add("root");

        FloatingMoneyBackground background = new FloatingMoneyBackground(18);
        background.prefWidthProperty().bind(root.widthProperty());
        background.prefHeightProperty().bind(root.heightProperty());

        VBox card = new VBox(14);
        card.getStyleClass().add("auth-card");
        card.setAlignment(Pos.CENTER);
        card.setMaxWidth(340);
        card.setMaxHeight(VBox.USE_PREF_SIZE);

        Label title = new Label("Welcome back");
        title.getStyleClass().add("title-label");

        User lookupUser = DataStore.findUserByMobile(mobileNumber);
        Label subtitle = new Label(lookupUser != null ? lookupUser.getUsername() : mobileNumber);
        subtitle.getStyleClass().add("subtitle-label");

        PasswordField pinField = new PasswordField();
        pinField.setPromptText("Enter PIN");
        pinField.getStyleClass().add("field");

        Label errorLabel = new Label();
        errorLabel.getStyleClass().add("error-label");

        Button unlockBtn = new Button("Unlock");
        unlockBtn.getStyleClass().add("btn-primary");
        unlockBtn.setMaxWidth(Double.MAX_VALUE);
        unlockBtn.setDefaultButton(true);

        unlockBtn.setOnAction(e -> {
            String pin = pinField.getText().trim();
            User user = DataStore.findUserByMobile(mobileNumber);

            if (user == null) {
                SessionManager.clear();
                SceneManager.showLogin();
                return;
            }

            if (!PasswordUtil.matches(pin, user.getPin())) {
                errorLabel.setText("Incorrect PIN.");
                return;
            }

            SceneManager.showDashboard(user);
        });

        Label switchAccountLink = new Label("Not you? Log in with a different account");
        switchAccountLink.getStyleClass().add("link-label");
        switchAccountLink.setOnMouseClicked(e -> {
            SessionManager.clear();
            SceneManager.showLogin();
        });

        VBox form = new VBox(12, pinField, errorLabel, unlockBtn);
        form.setMaxWidth(280);
        form.setAlignment(Pos.CENTER);

        card.getChildren().addAll(title, subtitle, form, switchAccountLink);

        Button themeToggle = ThemeToggleButton.create();
        StackPane.setAlignment(themeToggle, Pos.TOP_RIGHT);
        StackPane.setMargin(themeToggle, new Insets(16));

        root.getChildren().addAll(background, card, themeToggle);
    }

    public StackPane getView() {
        return root;
    }
}
