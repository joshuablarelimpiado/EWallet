package com.ewallet;

/**
 * Reward tier derived from a user's accumulated points. Points are earned
 * at 1 pt per ₱10,000 moved (deposit + withdraw + transfer combined),
 * tracked in DataStore.awardPoints(). Tier is computed on the fly from
 * the points total rather than stored separately.
 */
public enum RewardTier {
    NEW("New", 0),
    AVERAGE("Average", 10),
    VIP("VIP", 50);

    private final String label;
    private final int minPoints;

    RewardTier(String label, int minPoints) {
        this.label = label;
        this.minPoints = minPoints;
    }

    public String getLabel() { return label; }

    public static RewardTier fromPoints(int points) {
        if (points >= VIP.minPoints) return VIP;
        if (points >= AVERAGE.minPoints) return AVERAGE;
        return NEW;
    }

    /** Points needed to reach the next tier, or -1 if already at the top tier. */
    public static int pointsToNextTier(int points) {
        RewardTier current = fromPoints(points);
        if (current == VIP) return -1;
        if (current == NEW) return AVERAGE.minPoints - points;
        return VIP.minPoints - points;
    }
}
