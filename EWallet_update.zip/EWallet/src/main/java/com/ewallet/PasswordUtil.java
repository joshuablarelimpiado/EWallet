package com.ewallet;

import org.mindrot.jbcrypt.BCrypt;

public class PasswordUtil {

    /** Hashes a plaintext value (password, PIN, or recovery code) for storage. */
    public static String hash(String plainText) {
        return BCrypt.hashpw(plainText, BCrypt.gensalt());
    }

    /** Checks a plaintext value against a stored hash. */
    public static boolean matches(String plainText, String hashed) {
        if (plainText == null || hashed == null) return false;
        try {
            return BCrypt.checkpw(plainText, hashed);
        } catch (IllegalArgumentException e) {
            // hashed value wasn't a valid bcrypt hash (e.g. old plaintext data)
            return false;
        }
    }

    /**
     * Password strength check: at least 8 characters, with at least one
     * letter, one digit, and one of the allowed special characters.
     * Returns null if the password passes, or an error message if it fails.
     */
    public static String validateStrength(String password) {
        if (password == null || password.length() < 8) {
            return "Password must be at least 8 characters long.";
        }
        if (!password.matches(".*[A-Za-z].*")) {
            return "Password must contain at least one letter.";
        }
        if (!password.matches(".*\\d.*")) {
            return "Password must contain at least one number.";
        }
        if (!password.matches(".*[!@#$%^&*()\\-_=+\\[\\]{};:'\",.<>/?].*")) {
            return "Password must contain at least one special character (e.g. !@#$%).";
        }
        return null;
    }
}
