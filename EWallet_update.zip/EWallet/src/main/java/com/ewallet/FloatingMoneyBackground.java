package com.ewallet;

import javafx.animation.*;
import javafx.application.Platform;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.util.Duration;

import java.util.Random;

public class FloatingMoneyBackground extends Pane {

    private static final Random RANDOM = new Random();
    private boolean initialized = false;

    public FloatingMoneyBackground(int symbolCount) {
        setMouseTransparent(true);
        setPickOnBounds(false);

        widthProperty().addListener((obs, oldVal, newVal) -> tryInit(symbolCount));
        heightProperty().addListener((obs, oldVal, newVal) -> tryInit(symbolCount));

        Platform.runLater(() -> tryInit(symbolCount));
    }

    private void tryInit(int symbolCount) {
        if (initialized) return;
        if (getWidth() <= 0 || getHeight() <= 0) return;
        initialized = true;
        for (int i = 0; i < symbolCount; i++) {
            addFloatingSymbol();
        }
    }

    private void addFloatingSymbol() {
        Text symbol = new Text("\u20B1");
        symbol.setFont(Font.font("Segoe UI", FontWeight.BOLD, 18 + RANDOM.nextInt(26)));

        double opacity = 0.05 + RANDOM.nextDouble() * 0.10;
        symbol.setFill(Color.web("#4FE3C1", opacity));

        double xPercent = RANDOM.nextDouble();
        double yStartPercent = 1.0 + RANDOM.nextDouble() * 0.5;

        symbol.layoutXProperty().bind(widthProperty().multiply(xPercent));
        symbol.setLayoutY(getHeight() * yStartPercent);

        heightProperty().addListener((obs, oldH, newH) -> symbol.setLayoutY(newH.doubleValue() * yStartPercent));

        getChildren().add(symbol);

        double duration = 14 + RANDOM.nextDouble() * 14;
        double travelDistance = getHeight() * 1.7;

        TranslateTransition drift = new TranslateTransition(Duration.seconds(duration), symbol);
        drift.setByY(-travelDistance);
        drift.setInterpolator(Interpolator.LINEAR);
        drift.setCycleCount(Animation.INDEFINITE);

        RotateTransition spin = new RotateTransition(Duration.seconds(6 + RANDOM.nextDouble() * 8), symbol);
        spin.setByAngle(RANDOM.nextBoolean() ? 360 : -360);
        spin.setInterpolator(Interpolator.LINEAR);
        spin.setCycleCount(Animation.INDEFINITE);

        TranslateTransition sway = new TranslateTransition(Duration.seconds(3 + RANDOM.nextDouble() * 3), symbol);
        sway.setByX(10 + RANDOM.nextDouble() * 15);
        sway.setAutoReverse(true);
        sway.setCycleCount(Animation.INDEFINITE);
        sway.setInterpolator(Interpolator.EASE_BOTH);

        PauseTransition delay = new PauseTransition(Duration.seconds(RANDOM.nextDouble() * duration));
        delay.setOnFinished(e -> {
            drift.play();
            spin.play();
            sway.play();
        });
        delay.play();
    }
}
