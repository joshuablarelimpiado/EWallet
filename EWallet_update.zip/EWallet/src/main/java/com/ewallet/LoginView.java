package com.ewallet;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

public class LoginView {

    private final StackPane root = new StackPane();

    public LoginView() {
        root.getStyleClass().add("root");

        FloatingMoneyBackground background = new FloatingMoneyBackground(18);
        background.prefWidthProperty().bind(root.widthProperty());
        background.prefHeightProperty().bind(root.heightProperty());

        VBox card = new VBox(14);
        card.getStyleClass().add("auth-card");
        card.setAlignment(Pos.CENTER);
        card.setMaxWidth(340);
        card.setMaxHeight(VBox.USE_PREF_SIZE);

        Label title = new Label("E-Wallet");
        title.getStyleClass().add("title-label");

        Label subtitle = new Label("Log in to manage your balance");
        subtitle.getStyleClass().add("subtitle-label");

        TextField loginField = new TextField();
        loginField.setPromptText("Mobile number or username");
        loginField.getStyleClass().add("field");

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");
        passwordField.getStyleClass().add("field");

        Label errorLabel = new Label();
        errorLabel.getStyleClass().add("error-label");
        errorLabel.setWrapText(true);

        Button loginBtn = new Button("Log In");
        loginBtn.getStyleClass().add("btn-primary");
        loginBtn.setMaxWidth(Double.MAX_VALUE);
        loginBtn.setDefaultButton(true);

        loginBtn.setOnAction(e -> {
            String identifier = loginField.getText().trim();
            String password = passwordField.getText();

            if (identifier.isEmpty() || password.isEmpty()) {
                errorLabel.setText("Please enter your mobile number or username, and password.");
                return;
            }

            // Accept either a 10-digit mobile number or a username in the same field.
            User user = MobileNumberUtil.isValid(identifier)
                    ? DataStore.findUserByMobile(identifier)
                    : DataStore.findUserByUsername(identifier);

            if (user == null || !PasswordUtil.matches(password, user.getPassword())) {
                errorLabel.setText("Invalid mobile number/username or password.");
                return;
            }

            SessionManager.save(user.getMobileNumber());
            SceneManager.showDashboard(user);
        });

        Label registerLink = new Label("Don't have an account? Register here");
        registerLink.getStyleClass().add("link-label");
        registerLink.setOnMouseClicked(e -> SceneManager.showRegister());

        Label forgotLink = new Label("Forgot password?");
        forgotLink.getStyleClass().add("link-label");
        forgotLink.setOnMouseClicked(e -> SceneManager.showForgotPassword());

        VBox form = new VBox(12, loginField, passwordField, errorLabel, loginBtn);
        form.setMaxWidth(280);
        form.setAlignment(Pos.CENTER);

        HBox links = new HBox(16, registerLink, forgotLink);
        links.setAlignment(Pos.CENTER);

        card.getChildren().addAll(title, subtitle, form, links);

        Button themeToggle = ThemeToggleButton.create();
        StackPane.setAlignment(themeToggle, Pos.TOP_RIGHT);
        StackPane.setMargin(themeToggle, new Insets(16));

        root.getChildren().addAll(background, card, themeToggle);
    }

    public StackPane getView() {
        return root;
    }
}
