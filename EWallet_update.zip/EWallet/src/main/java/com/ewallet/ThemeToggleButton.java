package com.ewallet;

import javafx.scene.control.Button;

public class ThemeToggleButton {

    public static Button create() {
        Button button = new Button(ThemeManager.getCurrentTheme().getIcon());
        button.getStyleClass().add("theme-toggle");

        button.setOnAction(e -> {
            ThemeManager.toggle(SceneManager.getScene());
            button.setText(ThemeManager.getCurrentTheme().getIcon());
        });

        return button;
    }
}
