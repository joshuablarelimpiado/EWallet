package com.ewallet;

public class MobileNumberUtil {

    /**
     * A valid local mobile number: exactly 10 digits, no dashes/spaces,
     * and must start with 9 (standard PH mobile prefix format used after
     * the +63 country code, e.g. +63 917 123 4567 -> stored as 9171234567).
     */
    public static boolean isValid(String number) {
        return number != null && number.matches("9\\d{9}");
    }

    /** Formats a stored 10-digit number for display as +63 9XX XXX XXXX. */
    public static String formatDisplay(String number) {
        if (!isValid(number)) return number;
        return "+63 " + number.substring(0, 3) + " " + number.substring(3, 6) + " " + number.substring(6);
    }
}
