package com.ewallet;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

public class ForgotPasswordView {

    private final StackPane root = new StackPane();

    public ForgotPasswordView() {
        root.getStyleClass().add("root");

        FloatingMoneyBackground background = new FloatingMoneyBackground(18);
        background.prefWidthProperty().bind(root.widthProperty());
        background.prefHeightProperty().bind(root.heightProperty());

        VBox card = new VBox(14);
        card.getStyleClass().add("auth-card");
        card.setAlignment(Pos.CENTER);
        card.setMaxWidth(340);
        card.setMaxHeight(VBox.USE_PREF_SIZE);

        Label title = new Label("Reset Password");
        title.getStyleClass().add("title-label");

        Label subtitle = new Label("Enter your mobile number and recovery code");
        subtitle.getStyleClass().add("subtitle-label");
        subtitle.setWrapText(true);

        Label countryCode = new Label("+63");
        countryCode.getStyleClass().add("subtitle-label");
        TextField mobileField = new TextField();
        mobileField.setPromptText("Mobile number");
        mobileField.getStyleClass().add("field");
        mobileField.textProperty().addListener((obs, oldVal, newVal) -> {
            String digitsOnly = newVal.replaceAll("\\D", "");
            if (digitsOnly.length() > 10) digitsOnly = digitsOnly.substring(0, 10);
            if (!digitsOnly.equals(newVal)) mobileField.setText(digitsOnly);
        });
        HBox mobileRow = new HBox(8, countryCode, mobileField);
        mobileRow.setAlignment(Pos.CENTER_LEFT);
        HBox.setHgrow(mobileField, Priority.ALWAYS);

        PasswordField recoveryField = new PasswordField();
        recoveryField.setPromptText("Recovery code");
        recoveryField.getStyleClass().add("field");

        PasswordField newPasswordField = new PasswordField();
        newPasswordField.setPromptText("New password");
        newPasswordField.getStyleClass().add("field");

        PasswordField confirmField = new PasswordField();
        confirmField.setPromptText("Confirm new password");
        confirmField.getStyleClass().add("field");

        Label passwordHint = new Label("At least 8 characters, with a letter, a number, and a special character.");
        passwordHint.getStyleClass().add("subtitle-label");
        passwordHint.setWrapText(true);
        passwordHint.setStyle("-fx-font-size: 11px;");

        Label errorLabel = new Label();
        errorLabel.getStyleClass().add("error-label");
        errorLabel.setWrapText(true);

        Button resetBtn = new Button("Reset Password");
        resetBtn.getStyleClass().add("btn-primary");
        resetBtn.setMaxWidth(Double.MAX_VALUE);
        resetBtn.setDefaultButton(true);

        resetBtn.setOnAction(e -> {
            String mobile = mobileField.getText().trim();
            String recoveryCode = recoveryField.getText();
            String newPassword = newPasswordField.getText();
            String confirm = confirmField.getText();

            if (mobile.isEmpty() || recoveryCode.isEmpty() || newPassword.isEmpty()) {
                errorLabel.setText("Please fill in all fields.");
                return;
            }
            if (!MobileNumberUtil.isValid(mobile)) {
                errorLabel.setText("Enter a valid 10-digit mobile number.");
                return;
            }
            if (!newPassword.equals(confirm)) {
                errorLabel.setText("Passwords do not match.");
                return;
            }
            String strengthError = PasswordUtil.validateStrength(newPassword);
            if (strengthError != null) {
                errorLabel.setText(strengthError);
                return;
            }

            User user = DataStore.findUserByMobileIncludingInactive(mobile);
            if (user == null || !user.isActive() || !PasswordUtil.matches(recoveryCode, user.getRecoveryCode())) {
                errorLabel.setText("Mobile number and recovery code do not match.");
                return;
            }

            boolean success = DataStore.resetPassword(user.getId(), newPassword);
            if (success) {
                Alert done = new Alert(Alert.AlertType.INFORMATION);
                done.setTitle("Password Reset");
                done.setHeaderText(null);
                done.setContentText("Your password has been reset. You can now log in with your new password.");
                done.showAndWait();
                SceneManager.showLogin();
            } else {
                errorLabel.setText("Something went wrong. Please try again.");
            }
        });

        Label backLink = new Label("Back to login");
        backLink.getStyleClass().add("link-label");
        backLink.setOnMouseClicked(e -> SceneManager.showLogin());

        VBox form = new VBox(12, mobileRow, recoveryField, newPasswordField, confirmField, passwordHint, errorLabel, resetBtn);
        form.setMaxWidth(280);
        form.setAlignment(Pos.CENTER);

        card.getChildren().addAll(title, subtitle, form, backLink);

        Button themeToggle = ThemeToggleButton.create();
        StackPane.setAlignment(themeToggle, Pos.TOP_RIGHT);
        StackPane.setMargin(themeToggle, new Insets(16));

        root.getChildren().addAll(background, card, themeToggle);
    }

    public StackPane getView() {
        return root;
    }
}
