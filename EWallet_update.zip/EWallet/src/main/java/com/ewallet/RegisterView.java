package com.ewallet;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

public class RegisterView {

    private final StackPane root = new StackPane();

    public RegisterView() {
        root.getStyleClass().add("root");

        FloatingMoneyBackground background = new FloatingMoneyBackground(18);
        background.prefWidthProperty().bind(root.widthProperty());
        background.prefHeightProperty().bind(root.heightProperty());

        VBox card = new VBox(14);
        card.getStyleClass().add("auth-card");
        card.setAlignment(Pos.CENTER);
        card.setMaxWidth(360);
        card.setMaxHeight(VBox.USE_PREF_SIZE);

        Label title = new Label("Create Account");
        title.getStyleClass().add("title-label");

        Label subtitle = new Label("Sign up to start using E-Wallet");
        subtitle.getStyleClass().add("subtitle-label");

        TextField usernameField = new TextField();
        usernameField.setPromptText("Choose a username (display name)");
        usernameField.getStyleClass().add("field");

        Label countryCode = new Label("+63");
        countryCode.getStyleClass().add("subtitle-label");
        TextField mobileField = new TextField();
        mobileField.setPromptText("9XXXXXXXXX (10 digits)");
        mobileField.getStyleClass().add("field");
        mobileField.textProperty().addListener((obs, oldVal, newVal) -> {
            String digitsOnly = newVal.replaceAll("\\D", "");
            if (digitsOnly.length() > 10) digitsOnly = digitsOnly.substring(0, 10);
            if (!digitsOnly.equals(newVal)) mobileField.setText(digitsOnly);
        });
        HBox mobileRow = new HBox(8, countryCode, mobileField);
        mobileRow.setAlignment(Pos.CENTER_LEFT);
        HBox.setHgrow(mobileField, javafx.scene.layout.Priority.ALWAYS);

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Choose a password");
        passwordField.getStyleClass().add("field");

        PasswordField confirmField = new PasswordField();
        confirmField.setPromptText("Confirm password");
        confirmField.getStyleClass().add("field");

        Label passwordHint = new Label("At least 8 characters, with a letter, a number, and a special character.");
        passwordHint.getStyleClass().add("subtitle-label");
        passwordHint.setWrapText(true);
        passwordHint.setStyle("-fx-font-size: 11px;");

        PasswordField pinField = new PasswordField();
        pinField.setPromptText("Choose a 4-digit PIN");
        pinField.getStyleClass().add("field");

        PasswordField recoveryField = new PasswordField();
        recoveryField.setPromptText("Create a recovery code (for forgot password)");
        recoveryField.getStyleClass().add("field");

        Label recoveryHint = new Label("Save this somewhere safe. You'll need it to reset your password.");
        recoveryHint.getStyleClass().add("subtitle-label");
        recoveryHint.setWrapText(true);
        recoveryHint.setStyle("-fx-font-size: 11px;");

        Label errorLabel = new Label();
        errorLabel.getStyleClass().add("error-label");
        errorLabel.setWrapText(true);

        Button registerBtn = new Button("Register");
        registerBtn.getStyleClass().add("btn-primary");
        registerBtn.setMaxWidth(Double.MAX_VALUE);
        registerBtn.setDefaultButton(true);

        registerBtn.setOnAction(e -> {
            String rawUsername = usernameField.getText();
            String mobile = mobileField.getText().trim();
            String password = passwordField.getText();
            String confirm = confirmField.getText();
            String pin = pinField.getText().trim();
            String recoveryCode = recoveryField.getText();

            String usernameError = UsernameUtil.validate(rawUsername);
            if (usernameError != null) {
                errorLabel.setText(usernameError);
                return;
            }
            if (!MobileNumberUtil.isValid(mobile)) {
                errorLabel.setText("Enter a valid 10-digit mobile number starting with 9 (e.g. 9171234567).");
                return;
            }
            if (DataStore.isReservedMobile(mobile)) {
                errorLabel.setText("That mobile number is reserved for the system admin account. Please use a different number.");
                return;
            }
            if (password.isEmpty() || pin.isEmpty() || recoveryCode.isEmpty()) {
                errorLabel.setText("Please fill in all fields.");
                return;
            }
            if (!password.equals(confirm)) {
                errorLabel.setText("Passwords do not match.");
                return;
            }
            String strengthError = PasswordUtil.validateStrength(password);
            if (strengthError != null) {
                errorLabel.setText(strengthError);
                return;
            }
            if (!pin.matches("\\d{4}")) {
                errorLabel.setText("PIN must be exactly 4 digits.");
                return;
            }
            if (recoveryCode.trim().length() < 4) {
                errorLabel.setText("Recovery code must be at least 4 characters.");
                return;
            }

            String cleanUsername = UsernameUtil.clean(rawUsername);
            DataStore.RegisterResult result = DataStore.registerUser(
                    cleanUsername, mobile, password, pin, recoveryCode.trim());

            switch (result) {
                case SUCCESS -> SceneManager.showLogin();
                case USERNAME_TAKEN -> errorLabel.setText("That username is already taken.");
                case MOBILE_TAKEN -> errorLabel.setText("That mobile number is already registered.");
                case RESERVED_MOBILE -> errorLabel.setText("That mobile number is reserved for the system admin account. Please use a different number.");
                default -> errorLabel.setText("Something went wrong. Please try again.");
            }
        });

        Button backBtn = new Button("Back to Login");
        backBtn.getStyleClass().add("btn-secondary");
        backBtn.setMaxWidth(Double.MAX_VALUE);
        backBtn.setOnAction(e -> SceneManager.showLogin());

        VBox form = new VBox(10, usernameField, mobileRow, passwordField, confirmField, passwordHint,
                pinField, recoveryField, recoveryHint, errorLabel, registerBtn, backBtn);
        form.setMaxWidth(300);
        form.setAlignment(Pos.CENTER);

        ScrollPane scrollPane = new ScrollPane(form);
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background: transparent; -fx-background-color: transparent;");
        scrollPane.setMaxHeight(420);

        card.getChildren().addAll(title, subtitle, scrollPane);

        Button themeToggle = ThemeToggleButton.create();
        StackPane.setAlignment(themeToggle, Pos.TOP_RIGHT);
        StackPane.setMargin(themeToggle, new Insets(16));

        root.getChildren().addAll(background, card, themeToggle);
    }

    public StackPane getView() {
        return root;
    }
}
