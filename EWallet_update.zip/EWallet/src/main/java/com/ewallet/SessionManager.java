package com.ewallet;

import java.io.*;

public class SessionManager {

    private static final String SESSION_FILE = "session.dat";

    public static void save(String username) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(SESSION_FILE))) {
            writer.print(username);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String load() {
        File file = new File(SESSION_FILE);
        if (!file.exists()) return null;
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line = reader.readLine();
            return (line == null || line.isBlank()) ? null : line.trim();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void clear() {
        File file = new File(SESSION_FILE);
        if (file.exists()) file.delete();
    }
}
