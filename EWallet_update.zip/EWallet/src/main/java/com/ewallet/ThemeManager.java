package com.ewallet;

import javafx.scene.Scene;

import java.io.*;

public class ThemeManager {

    public enum Theme {
        DARK("/dark-theme.css", "\uD83C\uDF19"),
        LIGHT("/light-theme.css", "\u2600");

        private final String cssPath;
        private final String icon;

        Theme(String cssPath, String icon) {
            this.cssPath = cssPath;
            this.icon = icon;
        }

        public String getCssPath() { return cssPath; }
        public String getIcon() { return icon; }

        public Theme opposite() {
            return this == DARK ? LIGHT : DARK;
        }
    }

    private static final String PREFS_FILE = "theme_prefs.ser";
    private static Theme currentTheme = Theme.DARK;

    public static void load() {
        File file = new File(PREFS_FILE);
        if (!file.exists()) return;
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            String name = (String) ois.readObject();
            currentTheme = Theme.valueOf(name);
        } catch (Exception e) {
            currentTheme = Theme.DARK;
        }
    }

    private static void save() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(PREFS_FILE))) {
            oos.writeObject(currentTheme.name());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Theme getCurrentTheme() {
        return currentTheme;
    }

    public static void applyTo(Scene scene) {
        if (scene == null) return;
        scene.getStylesheets().clear();
        scene.getStylesheets().add(ThemeManager.class.getResource(currentTheme.getCssPath()).toExternalForm());
    }

    public static void toggle(Scene scene) {
        currentTheme = currentTheme.opposite();
        applyTo(scene);
        save();
    }
}
