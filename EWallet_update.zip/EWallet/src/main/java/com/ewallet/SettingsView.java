package com.ewallet;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.time.format.DateTimeFormatter;

public class SettingsView {

    private final BorderPane root = new BorderPane();
    private final User user;
    private Label statusLabel;

    private static final DateTimeFormatter DATE_FORMAT =
            DateTimeFormatter.ofPattern("MMMM d, yyyy 'at' h:mm a");

    public SettingsView(User user) {
        this.user = user;
        root.getStyleClass().add("root");
        root.setPadding(new Insets(24));

        root.setTop(buildHeader());
        root.setCenter(buildCenter());
        BorderPane.setMargin(root.getCenter(), new Insets(20, 0, 0, 0));
    }

    private HBox buildHeader() {
        Label title = new Label("Account Settings");
        title.getStyleClass().add("username-label");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Label back = new Label("Back to Dashboard");
        back.getStyleClass().add("logout-label");
        back.setOnMouseClicked(e -> SceneManager.showDashboard(user));

        HBox header = new HBox(14, title, spacer, back);
        header.setAlignment(Pos.CENTER_LEFT);
        return header;
    }

    private VBox buildCenter() {
        statusLabel = new Label();
        statusLabel.setWrapText(true);

        VBox infoSection = buildInfoSection();
        VBox editSection = buildEditSection();
        VBox pinSection = buildPinSection();
        VBox dangerSection = buildDangerSection();

        VBox center = new VBox(24, infoSection, editSection, pinSection, dangerSection, statusLabel);

        ScrollPane scrollPane = new ScrollPane(center);
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background: transparent; -fx-background-color: transparent;");

        VBox wrapper = new VBox(scrollPane);
        VBox.setVgrow(scrollPane, Priority.ALWAYS);
        return wrapper;
    }

    private VBox buildInfoSection() {
        Label sectionLabel = new Label("Account Info");
        sectionLabel.getStyleClass().add("section-label");

        Label createdLabel = new Label("Account created: " + user.getCreatedAt().format(DATE_FORMAT));
        createdLabel.getStyleClass().add("subtitle-label");

        Label usernameLabel = new Label("Current username: " + user.getUsername());
        usernameLabel.getStyleClass().add("subtitle-label");

        Label mobileLabel = new Label("Mobile number: " + MobileNumberUtil.formatDisplay(user.getMobileNumber()));
        mobileLabel.getStyleClass().add("subtitle-label");

        Label tierLabel = new Label("Reward tier: " + user.getTier().getLabel() + " (" + user.getPoints() + " pts)");
        tierLabel.getStyleClass().add("subtitle-label");

        return new VBox(6, sectionLabel, usernameLabel, mobileLabel, tierLabel, createdLabel);
    }

    private VBox buildEditSection() {
        Label sectionLabel = new Label("Update Information");
        sectionLabel.getStyleClass().add("section-label");

        Label note = new Label("Note: mobile number can't be changed here since it's your login ID. Contact an admin if it needs to change.");
        note.getStyleClass().add("subtitle-label");
        note.setWrapText(true);
        note.setStyle("-fx-font-size: 11px;");

        TextField usernameField = new TextField();
        usernameField.setPromptText("New username (leave blank to keep current)");
        usernameField.getStyleClass().add("field");

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("New password (leave blank to keep current)");
        passwordField.getStyleClass().add("field");

        Label passwordHint = new Label("At least 8 characters, with a letter, a number, and a special character.");
        passwordHint.getStyleClass().add("subtitle-label");
        passwordHint.setStyle("-fx-font-size: 11px;");
        passwordHint.setWrapText(true);

        Button saveBtn = new Button("Save Changes");
        saveBtn.getStyleClass().add("btn-primary");
        saveBtn.setOnAction(e -> {
            String rawUsername = usernameField.getText();
            String newUsername = rawUsername.isBlank() ? "" : rawUsername;
            String newPassword = passwordField.getText().trim();

            if (newUsername.isEmpty() && newPassword.isEmpty()) {
                showStatus("Nothing to update.", false);
                return;
            }
            if (!newUsername.isEmpty()) {
                String usernameError = UsernameUtil.validate(newUsername);
                if (usernameError != null) {
                    showStatus(usernameError, false);
                    return;
                }
                newUsername = UsernameUtil.clean(newUsername);
            }
            if (!newPassword.isEmpty()) {
                String strengthError = PasswordUtil.validateStrength(newPassword);
                if (strengthError != null) {
                    showStatus(strengthError, false);
                    return;
                }
            }

            boolean success = DataStore.updateUserInfo(
                    user.getId(),
                    newUsername.isEmpty() ? null : newUsername,
                    newPassword.isEmpty() ? null : newPassword,
                    null
            );

            if (!success) {
                showStatus("That username is already taken.", false);
                return;
            }

            if (!newUsername.isEmpty()) user.setUsername(newUsername);

            usernameField.clear();
            passwordField.clear();
            showStatus("Account updated successfully.", true);
            root.setCenter(buildCenter());
        });

        VBox section = new VBox(10, sectionLabel, note, usernameField, passwordField, passwordHint, saveBtn);
        return section;
    }

    private VBox buildPinSection() {
        Label sectionLabel = new Label("Change PIN");
        sectionLabel.getStyleClass().add("section-label");

        PasswordField pinField = new PasswordField();
        pinField.setPromptText("New 4-digit PIN");
        pinField.getStyleClass().add("field");

        Button savePinBtn = new Button("Update PIN");
        savePinBtn.getStyleClass().add("btn-secondary");
        savePinBtn.setOnAction(e -> {
            String newPin = pinField.getText().trim();
            if (newPin.isEmpty()) {
                showStatus("Enter a new PIN.", false);
                return;
            }
            if (!newPin.matches("\\d{4}")) {
                showStatus("PIN must be exactly 4 digits.", false);
                return;
            }
            boolean success = DataStore.updateUserInfo(user.getId(), null, null, newPin);
            if (success) {
                pinField.clear();
                showStatus("PIN updated successfully.", true);
            } else {
                showStatus("Something went wrong. Please try again.", false);
            }
        });

        return new VBox(10, sectionLabel, pinField, savePinBtn);
    }

    private VBox buildDangerSection() {
        Label sectionLabel = new Label("Danger Zone");
        sectionLabel.getStyleClass().add("section-label");

        Label warning = new Label("Deleting your account will deactivate it. You won't be able to log in, " +
                "and an administrator will need to restore the account if you change your mind.");
        warning.getStyleClass().add("subtitle-label");
        warning.setWrapText(true);
        warning.setMaxWidth(420);

        Button deleteBtn = new Button("Delete Account");
        deleteBtn.getStyleClass().add("btn-secondary");
        deleteBtn.setStyle("-fx-text-fill: #E5484D; -fx-border-color: #E5484D;");
        deleteBtn.setOnAction(e -> confirmDelete());

        return new VBox(10, sectionLabel, warning, deleteBtn);
    }

    private void confirmDelete() {
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Delete Account");
        confirm.setHeaderText("Are you sure you want to delete your account?");
        confirm.setContentText("This will deactivate \"" + user.getUsername() +
                "\" and log you out. This action requires an admin to reverse.");

        ButtonType deleteType = new ButtonType("Delete", ButtonBar.ButtonData.OK_DONE);
        ButtonType cancelType = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
        confirm.getButtonTypes().setAll(deleteType, cancelType);

        confirm.showAndWait().ifPresent(choice -> {
            if (choice == deleteType) {
                boolean success = DataStore.deactivateUser(user.getId());
                if (success) {
                    SessionManager.clear();
                    Alert done = new Alert(Alert.AlertType.INFORMATION);
                    done.setTitle("Account Deleted");
                    done.setHeaderText(null);
                    done.setContentText("Your account has been deactivated. You'll be returned to the login screen.");
                    done.showAndWait();
                    SceneManager.showLogin();
                } else {
                    showStatus("Something went wrong. Please try again.", false);
                }
            }
        });
    }

    private void showStatus(String message, boolean success) {
        statusLabel.getStyleClass().setAll(success ? "success-label" : "error-label");
        statusLabel.setText(message);
    }

    public BorderPane getView() {
        return root;
    }
}
