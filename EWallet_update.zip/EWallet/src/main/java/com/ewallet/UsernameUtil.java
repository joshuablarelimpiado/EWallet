package com.ewallet;

public class UsernameUtil {

    /**
     * Valid usernames: 3-30 characters after trimming, letters/numbers/
     * spaces/underscores/periods only, and not blank or whitespace-only.
     * Returns null if valid, or an error message if not.
     */
    public static String validate(String rawUsername) {
        if (rawUsername == null) return "Username is required.";
        String trimmed = rawUsername.trim();
        if (trimmed.isEmpty()) {
            return "Username cannot be blank or just spaces.";
        }
        if (trimmed.length() < 3) {
            return "Username must be at least 3 characters.";
        }
        if (trimmed.length() > 30) {
            return "Username must be at most 30 characters.";
        }
        if (!trimmed.matches("[A-Za-z0-9 _.]+")) {
            return "Username can only contain letters, numbers, spaces, underscores, and periods.";
        }
        return null;
    }

    /** Collapses internal whitespace and trims, for consistent storage. */
    public static String clean(String rawUsername) {
        return rawUsername.trim().replaceAll("\\s+", " ");
    }
}
