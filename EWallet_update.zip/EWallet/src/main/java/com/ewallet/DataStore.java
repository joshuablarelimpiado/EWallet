package com.ewallet;

import java.sql.*;
import java.time.LocalDateTime;

public class DataStore {

    private static final int PESOS_PER_POINT = 10_000;

    // Default admin credentials used only when no admin account exists yet.
    // Change ADMIN_PASSWORD here if you want a different default password;
    // it will be re-hashed automatically the next time the app starts.
    private static final String ADMIN_USERNAME = "admin";
    private static final String ADMIN_MOBILE = "9000000000";
    private static final String ADMIN_PASSWORD = "admin!123";
    private static final String ADMIN_PIN = "0000";
    private static final String ADMIN_RECOVERY_CODE = "ADMIN-RECOVERY-0000";

    // ---------------------------------------------------------------
    // Startup seeding
    // ---------------------------------------------------------------

    /**
     * Ensures a working admin account exists, called once on app startup.
     * schema.sql seeds a placeholder admin row with plaintext values (since
     * SQL alone can't call BCrypt), which can never pass PasswordUtil.matches().
     * This replaces that placeholder with a properly hashed admin account,
     * or does nothing if a real admin already exists.
     */
    public static void seedDefaultAdmin() {
        try (Connection conn = Database.connect()) {
            if (hasWorkingAdmin(conn)) {
                return;
            }
            // Remove the unusable placeholder seed row from schema.sql, if present.
            try (PreparedStatement del = conn.prepareStatement(
                    "DELETE FROM users WHERE mobile_number = ? AND is_admin = TRUE")) {
                del.setString(1, ADMIN_MOBILE);
                del.executeUpdate();
            }
            String sql = "INSERT INTO users (username, mobile_number, password, pin, recovery_code, balance, points, is_admin, is_active) " +
                    "VALUES (?, ?, ?, ?, ?, 0, 0, TRUE, TRUE)";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, ADMIN_USERNAME);
                ps.setString(2, ADMIN_MOBILE);
                ps.setString(3, PasswordUtil.hash(ADMIN_PASSWORD));
                ps.setString(4, PasswordUtil.hash(ADMIN_PIN));
                ps.setString(5, PasswordUtil.hash(ADMIN_RECOVERY_CODE));
                ps.executeUpdate();
                System.out.println("Seeded default admin account -> username: " + ADMIN_USERNAME +
                        ", password: " + ADMIN_PASSWORD);
            }
        } catch (SQLException e) {
            // Non-fatal: if seeding fails (e.g. DB not reachable yet), the app
            // still starts and the existing login error handling takes over.
            Database.showConnectionError(e);
        }
    }

    /** True if a row already exists with is_admin = TRUE and a real (bcrypt) password. */
    private static boolean hasWorkingAdmin(Connection conn) throws SQLException {
        String sql = "SELECT password FROM users WHERE is_admin = TRUE";
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                String storedPassword = rs.getString("password");
                if (storedPassword != null && storedPassword.startsWith("$2")) {
                    return true; // looks like a real bcrypt hash
                }
            }
        }
        return false;
    }

    // ---------------------------------------------------------------
    // Lookups
    // ---------------------------------------------------------------

    /** Login lookup: by mobile number, active accounts only. */
    public static User findUserByMobile(String mobileNumber) {
        String sql = "SELECT * FROM users WHERE mobile_number = ? AND is_active = TRUE";
        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, mobileNumber);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                User user = mapUser(rs);
                loadHistory(conn, user);
                return user;
            }
        } catch (SQLException e) {
            Database.showConnectionError(e);
        }
        return null;
    }

    /**
     * Looks up a user by mobile number regardless of active status — used
     * for the forgot-password flow, where a deactivated user shouldn't be
     * able to reset their way back in, so callers must check isActive().
     */
    public static User findUserByMobileIncludingInactive(String mobileNumber) {
        String sql = "SELECT * FROM users WHERE mobile_number = ?";
        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, mobileNumber);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                User user = mapUser(rs);
                loadHistory(conn, user);
                return user;
            }
        } catch (SQLException e) {
            Database.showConnectionError(e);
        }
        return null;
    }

    /** Login lookup: by username, active accounts only. */
    public static User findUserByUsername(String username) {
        String sql = "SELECT * FROM users WHERE username = ? AND is_active = TRUE";
        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                User user = mapUser(rs);
                loadHistory(conn, user);
                return user;
            }
        } catch (SQLException e) {
            Database.showConnectionError(e);
        }
        return null;
    }

    public static User findUserById(int userId) {
        String sql = "SELECT * FROM users WHERE id = ?";
        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                User user = mapUser(rs);
                loadHistory(conn, user);
                return user;
            }
        } catch (SQLException e) {
            Database.showConnectionError(e);
        }
        return null;
    }

    public static java.util.List<User> findAllUsers() {
        java.util.List<User> users = new java.util.ArrayList<>();
        String sql = "SELECT * FROM users WHERE is_admin = FALSE ORDER BY created_at DESC";
        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                User user = mapUser(rs);
                loadHistory(conn, user);
                users.add(user);
            }
        } catch (SQLException e) {
            Database.showConnectionError(e);
        }
        return users;
    }

    // ---------------------------------------------------------------
    // Registration
    // ---------------------------------------------------------------

    /**
     * Registers a new user. Relies on the database's UNIQUE constraints on
     * username and mobile_number as the real source of truth (catching the
     * SQLIntegrityConstraintViolationException) rather than a check-then-
     * insert, which would leave a race window between two simultaneous
     * registrations of the same username/number.
     */
    public static RegisterResult registerUser(String username, String mobileNumber, String password,
                                                String pin, String recoveryCode) {
        if (isReservedMobile(mobileNumber)) {
            return RegisterResult.RESERVED_MOBILE;
        }
        String sql = "INSERT INTO users (username, mobile_number, password, pin, recovery_code, balance, points, is_admin) " +
                "VALUES (?, ?, ?, ?, ?, 0, 0, FALSE)";
        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, mobileNumber);
            ps.setString(3, PasswordUtil.hash(password));
            ps.setString(4, PasswordUtil.hash(pin));
            ps.setString(5, PasswordUtil.hash(recoveryCode));
            ps.executeUpdate();
            return RegisterResult.SUCCESS;
        } catch (SQLIntegrityConstraintViolationException e) {
            // Unique constraint hit: figure out which one, best-effort.
            String msg = e.getMessage() == null ? "" : e.getMessage().toLowerCase();
            if (msg.contains("mobile_number")) return RegisterResult.MOBILE_TAKEN;
            if (msg.contains("username")) return RegisterResult.USERNAME_TAKEN;
            return RegisterResult.USERNAME_TAKEN;
        } catch (SQLException e) {
            Database.showConnectionError(e);
            return RegisterResult.ERROR;
        }
    }

    public enum RegisterResult { SUCCESS, USERNAME_TAKEN, MOBILE_TAKEN, RESERVED_MOBILE, ERROR }

    /** True if this mobile number is reserved for the system admin account and can't be self-registered. */
    public static boolean isReservedMobile(String mobileNumber) {
        return ADMIN_MOBILE.equals(mobileNumber);
    }

    // ---------------------------------------------------------------
    // Wallet operations
    // ---------------------------------------------------------------

    public static void deposit(User user, double amount) {
        double newBalance = user.getBalance() + amount;
        try (Connection conn = Database.connect()) {
            conn.setAutoCommit(false);
            try {
                updateBalance(conn, user.getId(), newBalance);
                insertTransaction(conn, user.getId(), "Cash In (Deposit)", amount, newBalance);
                int newPoints = awardPoints(conn, user.getId(), amount);
                conn.commit();
                user.setBalance(newBalance);
                user.setPoints(newPoints);
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (SQLException e) {
            Database.showConnectionError(e);
        }
    }

    public static boolean withdraw(User user, double amount) {
        try (Connection conn = Database.connect()) {
            conn.setAutoCommit(false);
            try {
                // Re-check balance inside the transaction to avoid a stale read.
                double currentBalance = lockAndGetBalance(conn, user.getId());
                if (amount > currentBalance) {
                    conn.rollback();
                    return false;
                }
                double newBalance = currentBalance - amount;
                updateBalance(conn, user.getId(), newBalance);
                insertTransaction(conn, user.getId(), "Cash Out (Withdraw)", -amount, newBalance);
                int newPoints = awardPoints(conn, user.getId(), amount);
                conn.commit();
                user.setBalance(newBalance);
                user.setPoints(newPoints);
                return true;
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (SQLException e) {
            Database.showConnectionError(e);
            return false;
        }
    }

    /**
     * Transfer, wrapped in a single DB transaction. Both balance updates
     * and both transaction log entries commit together or not at all,
     * preventing the double-spend / partial-transfer race that existed
     * with separate auto-committed statements.
     */
    public static boolean transfer(User sender, User recipient, double amount) {
        try (Connection conn = Database.connect()) {
            conn.setAutoCommit(false);
            try {
                double senderBalance = lockAndGetBalance(conn, sender.getId());
                if (amount > senderBalance) {
                    conn.rollback();
                    return false;
                }
                double recipientBalance = lockAndGetBalance(conn, recipient.getId());

                double senderNewBalance = senderBalance - amount;
                double recipientNewBalance = recipientBalance + amount;

                updateBalance(conn, sender.getId(), senderNewBalance);
                updateBalance(conn, recipient.getId(), recipientNewBalance);

                insertTransaction(conn, sender.getId(), "Sent to " + recipient.getUsername(), -amount, senderNewBalance);
                insertTransaction(conn, recipient.getId(), "Received from " + sender.getUsername(), amount, recipientNewBalance);

                int senderNewPoints = awardPoints(conn, sender.getId(), amount);

                conn.commit();

                sender.setBalance(senderNewBalance);
                sender.setPoints(senderNewPoints);
                recipient.setBalance(recipientNewBalance);
                return true;
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (SQLException e) {
            Database.showConnectionError(e);
            return false;
        }
    }

    /** Reads a user's current balance with a row lock, inside an existing transaction. */
    private static double lockAndGetBalance(Connection conn, int userId) throws SQLException {
        String sql = "SELECT balance FROM users WHERE id = ? FOR UPDATE";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getDouble("balance");
            throw new SQLException("User not found: " + userId);
        }
    }

    /**
     * Awards reward points at 1 pt per PESOS_PER_POINT moved, and returns
     * the user's updated point total. Must be called within an existing
     * transaction/connection so it commits atomically with the balance change.
     */
    private static int awardPoints(Connection conn, int userId, double amountMoved) throws SQLException {
        int earned = (int) (Math.abs(amountMoved) / PESOS_PER_POINT);
        if (earned <= 0) {
            return getPoints(conn, userId);
        }
        String sql = "UPDATE users SET points = points + ? WHERE id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, earned);
            ps.setInt(2, userId);
            ps.executeUpdate();
        }
        return getPoints(conn, userId);
    }

    private static int getPoints(Connection conn, int userId) throws SQLException {
        String sql = "SELECT points FROM users WHERE id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt("points");
            return 0;
        }
    }

    // ---------------------------------------------------------------
    // Account settings
    // ---------------------------------------------------------------

    /**
     * Updates username/password/pin for a user. Pass null (or blank) for any
     * field you don't want to change. Password and PIN are re-hashed here.
     */
    public static boolean updateUserInfo(int userId, String newUsername, String newPassword, String newPin) {
        StringBuilder sql = new StringBuilder("UPDATE users SET ");
        java.util.List<String> sets = new java.util.ArrayList<>();
        java.util.List<Object> values = new java.util.ArrayList<>();

        if (newUsername != null && !newUsername.isBlank()) {
            sets.add("username = ?");
            values.add(newUsername);
        }
        if (newPassword != null && !newPassword.isBlank()) {
            sets.add("password = ?");
            values.add(PasswordUtil.hash(newPassword));
        }
        if (newPin != null && !newPin.isBlank()) {
            sets.add("pin = ?");
            values.add(PasswordUtil.hash(newPin));
        }
        if (sets.isEmpty()) return true; // nothing to change

        sql.append(String.join(", ", sets)).append(" WHERE id = ?");
        values.add(userId);

        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            for (int i = 0; i < values.size(); i++) {
                ps.setObject(i + 1, values.get(i));
            }
            ps.executeUpdate();
            return true;
        } catch (SQLIntegrityConstraintViolationException e) {
            return false; // username taken
        } catch (SQLException e) {
            Database.showConnectionError(e);
            return false;
        }
    }

    /** Resets a user's password directly, used by the forgot-password flow after recovery code verification. */
    public static boolean resetPassword(int userId, String newPassword) {
        String sql = "UPDATE users SET password = ? WHERE id = ?";
        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, PasswordUtil.hash(newPassword));
            ps.setInt(2, userId);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            Database.showConnectionError(e);
            return false;
        }
    }

    /**
     * Soft delete: marks the account inactive instead of removing the row.
     * Keeps transaction history and referential integrity intact; an admin
     * can reactivate the account later if needed.
     */
    public static boolean deactivateUser(int userId) {
        String sql = "UPDATE users SET is_active = FALSE WHERE id = ?";
        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            Database.showConnectionError(e);
            return false;
        }
    }

    public static boolean reactivateUser(int userId) {
        String sql = "UPDATE users SET is_active = TRUE WHERE id = ?";
        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            Database.showConnectionError(e);
            return false;
        }
    }

    // ---------------------------------------------------------------
    // Admin: deactivate/reactivate with audit logging
    // ---------------------------------------------------------------

    public static boolean adminSetActive(int adminId, int targetUserId, boolean active) {
        boolean success = active ? reactivateUser(targetUserId) : deactivateUser(targetUserId);
        if (success) {
            logAdminAction(adminId, active ? "REACTIVATE_USER" : "DEACTIVATE_USER", targetUserId, null);
        }
        return success;
    }

    private static void logAdminAction(int adminId, String action, Integer targetUserId, String details) {
        String sql = "INSERT INTO admin_audit_log (admin_id, action, target_user_id, details) VALUES (?, ?, ?, ?)";
        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, adminId);
            ps.setString(2, action);
            if (targetUserId != null) ps.setInt(3, targetUserId); else ps.setNull(3, Types.INTEGER);
            ps.setString(4, details);
            ps.executeUpdate();
        } catch (SQLException e) {
            Database.showConnectionError(e);
        }
    }

    public static java.util.List<String> getAdminAuditLog(int limit) {
        java.util.List<String> entries = new java.util.ArrayList<>();
        String sql = "SELECT a.action, a.details, a.created_at, admin.username AS admin_name, " +
                "target.username AS target_name " +
                "FROM admin_audit_log a " +
                "JOIN users admin ON a.admin_id = admin.id " +
                "LEFT JOIN users target ON a.target_user_id = target.id " +
                "ORDER BY a.created_at DESC LIMIT ?";
        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, limit);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Timestamp ts = rs.getTimestamp("created_at");
                String target = rs.getString("target_name");
                entries.add(String.format("[%s] %s %s %s",
                        ts.toLocalDateTime().format(java.time.format.DateTimeFormatter.ofPattern("MMM dd HH:mm")),
                        rs.getString("admin_name"),
                        rs.getString("action"),
                        target != null ? "-> " + target : ""));
            }
        } catch (SQLException e) {
            Database.showConnectionError(e);
        }
        return entries;
    }

    // ---------------------------------------------------------------
    // Transactions / receipts
    // ---------------------------------------------------------------

    /** Looks up a single transaction by id, scoped to a user (so users can't view others' receipts by guessing ids). */
    public static Transaction findTransaction(int userId, int transactionId) {
        String sql = "SELECT * FROM transactions WHERE id = ? AND user_id = ?";
        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, transactionId);
            ps.setInt(2, userId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapTransaction(rs);
        } catch (SQLException e) {
            Database.showConnectionError(e);
        }
        return null;
    }

    // ---------------------------------------------------------------
    // Internal helpers
    // ---------------------------------------------------------------

    private static void updateBalance(Connection conn, int userId, double newBalance) throws SQLException {
        String sql = "UPDATE users SET balance = ? WHERE id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDouble(1, newBalance);
            ps.setInt(2, userId);
            ps.executeUpdate();
        }
    }

    private static void insertTransaction(Connection conn, int userId, String type, double amount, double balanceAfter) throws SQLException {
        String sql = "INSERT INTO transactions (user_id, type, amount, balance_after) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setString(2, type);
            ps.setDouble(3, amount);
            ps.setDouble(4, balanceAfter);
            ps.executeUpdate();
        }
    }

    private static void loadHistory(Connection conn, User user) throws SQLException {
        String sql = "SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC, id DESC";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, user.getId());
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                user.getHistory().add(mapTransaction(rs));
            }
        }
    }

    private static Transaction mapTransaction(ResultSet rs) throws SQLException {
        Timestamp ts = rs.getTimestamp("created_at");
        LocalDateTime dateTime = ts != null ? ts.toLocalDateTime() : LocalDateTime.now();
        return new Transaction(
                rs.getInt("id"),
                rs.getString("type"),
                rs.getDouble("amount"),
                rs.getDouble("balance_after"),
                dateTime
        );
    }

    private static User mapUser(ResultSet rs) throws SQLException {
        Timestamp createdTs = rs.getTimestamp("created_at");
        LocalDateTime createdAt = createdTs != null ? createdTs.toLocalDateTime() : LocalDateTime.now();
        return new User(
                rs.getInt("id"),
                rs.getString("username"),
                rs.getString("mobile_number"),
                rs.getString("password"),
                rs.getString("pin"),
                rs.getString("recovery_code"),
                rs.getDouble("balance"),
                rs.getInt("points"),
                rs.getBoolean("is_admin"),
                rs.getBoolean("is_active"),
                createdAt
        );
    }
}
